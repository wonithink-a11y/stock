BOOK3_MASTER.md

Book 3 — Implementation Master

«이 문서는 Book 3 전체 구현의 기준선이다.
AI Coding Agent는 Book 3 작업을 시작할 때 이 문서를 먼저 읽고, 작업 대상에 해당하는 Chapter를 추가로 읽는다.»

---

1. Document Role

Book 3는 투자 시스템의 실제 구현 명세다.

Book 1과 Book 2가 투자 시스템의 개념과 아키텍처를 정의한다면,

Book 1
= 투자 원리 / 판단 구조

Book 2
= 시스템 아키텍처 / Engine 구조

Book 3
= 실제 구현 / 검증 / 운영

이다.

Book 3의 목표는 설명을 많이 하는 것이 아니다.

Claude Code, Codex 등의 Coding Agent가 Chapter를 읽고 실제 Repository에 구현할 수 있는 수준의 명세를 제공하는 것이다.

---

2. AI Agent Reading Rule

Book 3 작업 시 항상 다음 순서로 읽는다.

1. BOOK3_MASTER.md
2. 현재 구현 상태 확인
3. 작업 대상 Chapter 확인
4. 해당 Chapter 읽기
5. 관련 Chapter 확인
6. 기존 Code 확인
7. 구현
8. Test
9. 결과 검증

모든 Chapter를 매번 읽지 않는다.

---

3. Chapter Selection Rule

작업 내용에 따라 다음 Chapter를 선택한다.

작업| 우선 Chapter
Repository 구조| Ch.1
Contract| Ch.2
Config / Policy| Ch.3
Feature Store| Ch.4
Data / Universe| Ch.5
PIT / Historical| Ch.6
Score / Confidence| Ch.7
Signal| Ch.8
Action| Ch.9
Risk| Ch.10
Order / Execution| Ch.11
Pipeline| Ch.12
Diagnostics| Ch.13
Monitoring| Ch.14
Research / Replay| Ch.15
Backtest| Ch.16
Production Execution| Ch.17
Data Contract / Validation| Ch.18
System Pipeline| Ch.19
Deployment / Go-Live| Ch.20

주의: 실제 Chapter 파일의 최종 번호가 변경되면 이 Master의 매핑도 함께 변경한다.

---

4. Book 3 Architecture

전체 시스템은 다음 방향으로 구성한다.

External Data
     ↓
Raw
     ↓
Normalized
     ↓
Feature
     ↓
Score
     ↓
Confidence
     ↓
Signal
     ↓
Action
     ↓
Risk
     ↓
OrderIntent
     ↓
Execution
     ↓
Broker
     ↓
Position
     ↓
Reconciliation

Control Plane:

Calendar
Universe
Policy
Config
Version
Monitoring
Diagnostics
Audit
Recovery
Deployment

---

5. Core Architecture Rule

의존 방향은 단방향이다.

Data
 ↓
Feature
 ↓
Score
 ↓
Signal
 ↓
Action
 ↓
Risk
 ↓
Execution

하위 계층이 상위 계층의 Business Logic을 호출하지 않는다.

예:

Execution → Scoring

과 같은 직접 의존은 금지한다.

---

6. Data Principle

Data는 다음 계층으로 분리한다.

Raw
 ↓
Normalized
 ↓
Feature

Raw Data는 원본 보존을 우선한다.

정규화된 결과를 Raw Data처럼 취급하지 않는다.

---

7. PIT Principle

Historical 계산에서 가장 중요한 규칙이다.

모든 Historical Decision은:

availableAt <= decisionTime

을 만족해야 한다.

미래에 공개된 정보를 과거 계산에 사용하지 않는다.

PIT 위반은 Warning이 아니라:

PIT_VIOLATION

이라는 명시적 Failure다.

Production 진입 전:

PIT Violations = 0

이어야 한다.

---

8. Feature Principle

Feature는 최소 다음 정보를 가져야 한다.

value
asOf
availableAt
quality
version
lineage

Feature의 존재와 Feature의 신뢰도를 혼동하지 않는다.

---

9. Score Principle

Score와 Confidence를 분리한다.

Score
=
투자 판단의 방향 / 강도

Confidence
=
데이터와 계산의 신뢰 수준

Score:

0 ~ 100

Risk Penalty:

negative only

Final Score:

0 ~ 100

범위를 벗어나지 않는다.

---

10. Confidence Principle

Confidence는 최소:

Coverage
Freshness
Quality

를 반영한다.

Score가 높더라도 Confidence가 낮으면 동일한 수준의 판단으로 취급하지 않는다.

---

11. Signal Principle

Signal은 Score만으로 결정하지 않는다.

기본 구조:

Score
+
Confidence
+
Market Regime
+
Policy

Signal 예:

BUY
SELL
HOLD
NO_SIGNAL
WITHHELD

---

12. Action Principle

Action은 Signal을 실제 Portfolio Action으로 변환한다.

Signal
 ↓
Current Position
 ↓
Portfolio Context
 ↓
Action

Action 예:

BUY
SELL
REDUCE
HOLD
BLOCK

---

13. Risk Principle

Risk는 Action보다 우선한다.

Action
 ↓
Risk
 ↓
Approved / Blocked

Risk를 우회하는 Execution 경로를 만들지 않는다.

Risk Failure:

NO ORDER

이다.

---

14. Execution Principle

Strategy가 Broker API를 직접 호출하지 않는다.

반드시:

Action
 ↓
Risk
 ↓
OrderIntent
 ↓
Execution Adapter
 ↓
Broker

구조를 사용한다.

---

15. Order Idempotency

중복 주문은 시스템의 치명적인 오류다.

최소:

runId
messageId
orderIntentId

를 관리한다.

동일 Order Intent가 재처리되어도 중복 주문이 발생하지 않아야 한다.

---

16. Unknown State Principle

다음 상태에서는 보수적으로 행동한다.

Unknown Broker
Unknown Order
Unknown Position
Position Mismatch

원칙:

Unknown
→ Reconcile
→ Validate
→ Resume

확인되지 않은 상태에서 신규 주문하지 않는다.

---

17. Reconciliation

항상 다음을 비교할 수 있어야 한다.

Internal Position
↕
Broker Position

Internal Order
↕
Broker Order

Mismatch:

NO NEW ORDER

---

18. Environment Separation

최소 환경:

DEV
TEST
REPLAY
PAPER
PRODUCTION

Production Credential을 다른 환경에서 사용하지 않는다.

환경별 Configuration과 Secret을 분리한다.

---

19. Research / Replay / Paper / Production

각 Mode의 목적은 다르다.

RESEARCH
= 실험

REPLAY
= Historical 재현

PAPER
= 실시간 Logic 검증

PRODUCTION
= 실제 실행

Research Code를 그대로 Production에 복사하지 않는다.

---

20. Replay Principle

동일한:

Dataset
+
Policy
+
Feature Version
+
Code Version
+
Config

에서는 동일한 결과를 재현할 수 있어야 한다.

Replay A == Replay B

---

21. Monitoring

최소 다음을 Monitoring한다.

Data
Feature
Score
Signal
Action
Risk
Execution
Broker
Position
Pipeline

---

22. Diagnostics

Failure를 조용히 무시하지 않는다.

최소:

failed
skipped
warnings
conflicts
stale

상태를 구분한다.

---

23. Kill Switch

최종 Execution Layer에 Kill Switch를 둔다.

KILL_SWITCH = ON

이면:

NO ORDER

자동으로 해제하지 않는다.

---

24. Production Guard

실제 주문 직전에 반드시 다음을 검사한다.

environment == PRODUCTION
executionEnabled == true
systemState == READY
riskState == PASS
positionState == RECONCILED
brokerState == CONNECTED
killSwitch == OFF

하나라도 실패하면:

ORDER BLOCKED

---

25. Recovery

Recovery 순서:

Detect
 ↓
Contain
 ↓
Isolate
 ↓
Recover
 ↓
Reconcile
 ↓
Validate
 ↓
Resume

Critical Failure 후 자동 Resume하지 않는다.

---

26. Versioning

최소 다음 Version을 추적한다.

Code Version
Policy Version
Config Version
Dataset Version
Feature Version
Artifact Hash

과거 결과를 재현할 수 있어야 한다.

---

27. Change Management

다음 변경은 반드시 Version을 증가시킨다.

Scoring Weight
Feature Formula
Risk Limit
Signal Threshold
Universe
Data Source
Execution Rule
Policy
Config
Schema

Silent Change를 금지한다.

---

28. Testing

테스트 순서:

Unit
 ↓
Integration
 ↓
Contract
 ↓
Regression
 ↓
Replay
 ↓
Paper
 ↓
Shadow
 ↓
Production Smoke

정상 경로뿐 아니라 Failure Path도 테스트한다.

---

29. Mandatory Failure Tests

최소 다음을 검증한다.

API Timeout
API Rate Limit
Missing Data
Stale Data
Invalid Schema
PIT Violation
Feature Failure
Score Failure
Risk Failure
Broker Timeout
Broker Disconnect
Order Reject
Partial Fill
Unknown Order
Position Mismatch
Duplicate Order
Storage Failure

---

30. Production Entry Criteria

Production 진입 전:

Schema PASS
Data PASS
PIT PASS
Feature PASS
Score PASS
Signal PASS
Risk PASS
Execution PASS
Monitoring PASS
Recovery PASS

이어야 한다.

---

31. Go-Live

최초 Production은:

Small Universe
+
Small Position
+
Strict Risk
+
Enhanced Monitoring

으로 시작한다.

이후:

Limited
 ↓
Expanded
 ↓
Full

로 확대한다.

---

32. Go-Live Invariants

Production에서 절대 깨지면 안 되는 규칙:

PIT Violation
→ NO ORDER

Risk Failure
→ NO ORDER

Unknown Position
→ NO ORDER

Unknown Broker State
→ NO ORDER

Kill Switch ON
→ NO ORDER

Environment != PRODUCTION
→ NO REAL ORDER

---

33. Final Repository Direction

권장 구조:

project/
│
├── app/
├── lib/
├── config/
├── policies/
├── pipeline/
├── tests/
├── scripts/
├── monitoring/
├── deployment/
├── docs/
│   └── book3/
│       ├── BOOK3_MASTER.md
│       ├── chapter01.md
│       ├── chapter02.md
│       ├── ...
│       └── chapter20.md
└── data/

---

34. Chapter Dependency Map

Ch01
  ↓
Ch02
  ↓
Ch03
  ↓
Ch04
  ↓
Ch05
  ↓
Ch06
  ↓
Ch07
  ↓
Ch08
  ↓
Ch09
  ↓
Ch10
  ↓
Ch11
  ↓
Ch12
  ↓
Ch13
  ↓
Ch14
  ↓
Ch15
  ↓
Ch16
  ↓
Ch17
  ↓
Ch18
  ↓
Ch19
  ↓
Ch20

실제 개발에서는 모든 Chapter를 순차적으로 구현할 필요는 없다.

Dependency가 있는 Chapter만 함께 확인한다.

---

35. Chapter Roles

Ch01 — Project Implementation Structure

Repository와 Module 구조.

읽어야 하는 경우:

Repository
Module
Directory
Dependency

변경.

---

Ch02 — Contracts

System Contract.

읽어야 하는 경우:

Schema
Interface
Input / Output
Validation

변경.

---

Ch03 — Config System

Configuration / Policy / Version.

---

Ch04 — Feature Store

Feature 저장·조회·Version·Quality.

---

Ch05 — Data / Universe

Universe, Calendar, Data ingestion.

---

Ch06 — PIT / Historical

Historical Data, Backfill, PIT.

Research / Backtest 작업에서는 핵심 Chapter.

---

Ch07 — Score / Confidence

Scoring Engine과 Confidence.

---

Ch08 — Signal

Score를 Signal로 변환.

---

Ch09 — Action

Signal을 Portfolio Action으로 변환.

---

Ch10 — Risk

Risk Control.

Execution보다 우선한다.

---

Ch11 — Order / Execution

OrderIntent, Broker Adapter, Execution State.

---

Ch12 — Pipeline

전체 Pipeline Orchestration.

---

Ch13 — Diagnostics

Failure / Warning / Skip / Conflict.

---

Ch14 — Monitoring

Metrics, Alert, Health.

---

Ch15 — Research / Replay

Research와 Historical Replay.

---

Ch16 — Backtest

Backtest Engine.

PIT 원칙을 반드시 적용한다.

---

Ch17 — Production Execution

실제 Broker Execution과 Production Guard.

---

Ch18 — Data Contract / Validation

Data Contract와 Validation.

---

Ch19 — Deployment / Runtime

Environment, Secrets, Deployment, Rollback.

---

Ch20 — Final Implementation / Go-Live

전체 구현 순서와 Production 진입 기준.

---

36. Implementation Priority

현재 구현에서는 다음 순서를 기본으로 한다.

P0
Contract
Schema
Data
PIT

P1
Feature
Score
Confidence

P2
Signal
Action
Risk

P3
Execution
Reconciliation

P4
Monitoring
Recovery
Deployment

P5
Paper
Shadow
Production

---

37. Current Project Principle

현재 시스템에서 가장 중요한 병목은 PIT가 보장된 Historical Data와 Financial Data의 완성도다.

따라서 기능을 추가하는 것보다:

Universe
→ Price
→ Financial
→ Flow
→ Feature
→ Score

Data Pipeline의 완성도를 우선한다.

---

38. Backfill Principle

Historical Backfill은 단순히 데이터를 채우는 작업이 아니다.

반드시:

Availability
Quality
PIT
Lineage
Version
Diagnostics

를 함께 관리한다.

---

39. Existing Backfill Decisions

현재 확정된 핵심 사항:

DART Financial Backfill
→ 2016부터

Weekly Snapshot
→ Friday Close 기준

Research Period
→ 2016 ~ 2026

KR Universe
→ KOSPI200 + KOSDAQ150 방향

US
→ KR과 분리하여 구현

실제 Repository의 최신 Policy/Config가 이 Master와 다르면 최신 확정 Policy/Config를 우선한다.

---

40. A-Phase Relation

Book 3 구현은 기존 A-Phase와 연결된다.

A0 Schema Freeze
A1 Universe Restoration
A2 Price Backfill
A3 Financial PIT Backfill
A4 Flow Backfill
A5 Assembly + Scoring
A6 Analysis
A7 State Replay
A8 Delisted / Management State
A9 US

현재 프로젝트에서 A1/A2 계열은 상당 부분 검증되었고, A3 Financial PIT가 핵심 병목이다.

따라서 새로운 Execution 기능보다 Data/PIT 완성도를 우선한다.

---

41. Existing Important Results

현재까지 확인된 중요한 기준:

A1a
2,579 records

A1b
1,222 records

A2a:

ResidualDailyChangeViolations = 0
datesNotInCalendar = 0
missingRate ≈ 0.056%
qualityExcludedCount = 20
qualityExcludedRate ≈ 0.775%

이 수치는 새로운 구현에서 임의로 변경하지 않는다.

단, Repository의 최신 검증 결과가 있으면 최신 결과를 기준으로 갱신한다.

---

42. Score Engine Principle

현재 Scoring 구조:

Normalizer
 ↓
Scoring Engine
 ↓
Validator
 ↓
Persistence

KR:

Fundamental 35%
Valuation   30%
Technical   15%
SupplyDemand 20%

US:

Fundamental 40%
Valuation   35%
Technical   15%
InstitutionalFlow 10%

현재 확정 Policy가 변경되기 전까지 기준선으로 유지한다.

---

43. Important Design Decisions

다음은 임의로 되돌리지 않는다.

Score ≠ Confidence

Risk Penalty = negative only

Final Score = 0~100 clamp

US supplyDemand
→ institutionalFlow

KR/US Pipeline
→ 분리

Research / Production
→ 분리

PIT
→ 필수

Execution
→ Risk 이후

Unknown Position
→ 신규 주문 금지

Unknown Order
→ 재주문 금지

---

44. Deprecated / Rejected Ideas

이미 기각된 설계를 다시 도입하지 않는다.

대표적으로:

미래정보를 이용한 Historical 계산
Score와 Confidence 통합
Risk 우회 Execution
Broker 직접 호출
Unknown 상태에서 자동 재주문
Production에서 Source 직접 수정
Secret의 Source 저장

---

45. Conflict Resolution

Book 3 Chapter와 실제 Repository가 충돌할 경우:

Latest Approved Policy
>
Latest Validated Repository Behavior
>
Book 3 Chapter
>
Older Conversation

순으로 판단한다.

단, 설계 변경이 발생하면 Master와 해당 Chapter를 함께 갱신한다.

---

46. AI Coding Agent Rule

Claude Code / Codex가 구현할 때:

1. 기존 Code를 먼저 검사한다.
2. 기존 Contract를 확인한다.
3. Master를 확인한다.
4. 관련 Chapter를 확인한다.
5. 기존 구현과 충돌 여부를 확인한다.
6. 필요한 최소 범위만 수정한다.
7. Test를 실행한다.
8. Regression을 확인한다.
9. 변경 내용을 기록한다.

기존 Code를 확인하지 않고 Chapter 내용만 보고 새 Module을 만들지 않는다.

---

47. Do Not Over-Implement

Book 3는 모든 가능한 기능을 구현하라는 문서가 아니다.

다음 원칙을 따른다.

필수 Contract
+
필수 Pipeline
+
필수 Risk
+
필수 Validation
+
필수 Monitoring

을 먼저 구현한다.

추가 기능은 별도 요구사항으로 관리한다.

---

48. Minimal Change Principle

기존 구현이 Contract를 만족하고 있다면 불필요하게 재작성하지 않는다.

Existing Code
+
Required Change
=
Minimal Diff

를 우선한다.

---

49. Completion Reporting

각 구현 작업 후 다음을 보고한다.

Changed
Tested
Passed
Failed
Remaining

예:

Changed:
lib/scoringEngine.js

Tested:
scoring regression

Passed:
9/9

Remaining:
A3 financial PIT

---

50. Final Book 3 Goal

Book 3의 최종 목표:

AI Agent가
Master를 읽고
작업 Chapter를 찾고
Repository를 검사한 뒤
필요한 부분만 구현하고
Test까지 수행할 수 있는 구조

이다.

따라서 Master 자체에는 세부 구현 코드를 넣지 않는다.

---

51. Final Reading Model

AI Agent의 기본 동작:

BOOK3_MASTER.md
       │
       ├── "무엇을 만드는가?"
       │
       ├── "전체 구조는?"
       │
       ├── "무엇이 중요한가?"
       │
       ├── "어떤 규칙을 절대 깨면 안 되는가?"
       │
       └── "어느 Chapter를 읽어야 하는가?"
                    │
                    ▼
              Chapter N
                    │
                    ▼
              Repository
                    │
                    ▼
              Implementation
                    │
                    ▼
                 Tests

---

52. Final Rule

Book 3의 모든 구현은 다음 한 문장으로 요약한다.

Master가 전체 방향을 결정하고,
Chapter가 구현 계약을 정의하며,
Repository가 실제 상태를 결정하고,
Test가 구현의 정합성을 검증한다.

이 원칙을 Book 3 전체에 적용한다.

---

53. Book 3 Status

Architecture        DEFINED
Contracts           DEFINED
Data                DEFINED
PIT                 DEFINED
Feature             DEFINED
Score               DEFINED
Confidence          DEFINED
Signal              DEFINED
Action              DEFINED
Risk                DEFINED
Execution           DEFINED
Monitoring          DEFINED
Recovery            DEFINED
Deployment          DEFINED
Go-Live             DEFINED

Book 3 Master Baseline — ACTIVE

이후 Book 3의 설계 변경은 이 문서를 기준으로 반영한다.