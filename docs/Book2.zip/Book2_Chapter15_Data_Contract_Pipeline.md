# Book 2 - Chapter 15

# Data Contract & Pipeline

## 1. 목적

모든 엔진이 동일한 데이터 계약(Data Contract)을 사용하도록 정의한다.

엔진은 내부 구현을 몰라도 계약만 알면 서로 통신할 수 있다.

------------------------------------------------------------------------

## 2. 핵심 원칙

-   Contract First
-   Version 관리
-   Immutable Snapshot
-   Backward Compatibility
-   Engine 간 직접 참조 금지

------------------------------------------------------------------------

## 3. 전체 파이프라인

``` text
Data Engine
    ↓
Feature Store
    ↓
Universe Engine
    ↓
Market Engine
    ↓
State Engine
    ↓
Event Engine
    ↓
Strategy Engine
    ↓
Confidence Engine
    ↓
Trade Risk
    ↓
Portfolio Risk
    ↓
Portfolio Engine
    ↓
Execution Engine
    ↓
Monitoring Engine
    ↓
Research Engine
```

------------------------------------------------------------------------

## 4. Snapshot 규약

모든 엔진은 Snapshot을 입력으로 받고 Snapshot을 출력한다.

예)

-   MarketSnapshot
-   StateSnapshot
-   FeatureSnapshot
-   StrategySignal
-   RiskDecision
-   PortfolioDecision
-   ExecutionResult

------------------------------------------------------------------------

## 5. 버전 관리

``` text
market.v1
feature.v1
strategy.v1
risk.v1
execution.v1
```

버전은 삭제하지 않고 추가한다.

------------------------------------------------------------------------

## 6. 공통 메타데이터

모든 Contract는 다음 필드를 포함한다.

``` python
{
 "version":"v1",
 "generatedAt":"ISO8601",
 "source":"ENGINE",
 "traceId":"UUID"
}
```

traceId는 전체 주문 흐름을 추적하는 데 사용한다.

------------------------------------------------------------------------

## 7. 오류 처리

Contract 검증 실패 시

-   다음 엔진으로 전달 금지
-   원인 기록
-   Monitoring 알림

------------------------------------------------------------------------

## 8. 구현 순서

1.  Base Contract
2.  Snapshot 정의
3.  Version 관리
4.  Validator
5.  Publisher
6.  Consumer

------------------------------------------------------------------------

## 9. 구현 원칙

-   dict 대신 명확한 모델 사용
-   모든 Contract 검증
-   동일 Contract를 백테스트와 실전에 사용
-   Contract 변경은 버전 증가

------------------------------------------------------------------------

## 10. 쉬운 설명

Data Contract는 엔진 간의 '약속'이다.

Strategy Engine이 어떻게 구현되었는지는 Risk Engine이 알 필요가 없다.

Risk Engine은 StrategySignal 계약만 이해하면 된다.

이 구조 덕분에 각 엔진을 독립적으로 개발, 테스트, 교체할 수 있으며,
Claude Code 역시 Contract를 기준으로 모듈을 구현할 수 있다.
