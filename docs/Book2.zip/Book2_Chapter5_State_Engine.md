# Book 2 - Chapter 5

# State Engine 설계

## 1. 목적

State Engine은 시장의 **현재 상태(Context)** 를 정의한다.

Market Engine이 "시장 점수"를 계산한다면, State Engine은 "시장이 어떤
흐름으로 움직이고 있는가"를 판단한다.

> 같은 Market Score 70이라도 Opening Breakout과 Closing Auction은 완전히
> 다른 전략을 사용해야 한다.

------------------------------------------------------------------------

# 2. 책임

-   시장 상태(State) 판정
-   상태 전이(State Transition)
-   상태 지속시간 관리
-   상태별 전략 파라미터 제공
-   상태 이력 기록

State Engine은 매수 신호를 만들지 않는다.

------------------------------------------------------------------------

# 3. 입력

-   Market Engine
-   PriceBar
-   Feature Snapshot
-   Event Engine
-   거래시간(Session)

------------------------------------------------------------------------

# 4. 출력

``` text
StateSnapshot
 ├─ session
 ├─ marketState
 ├─ confidence
 ├─ duration
 ├─ nextCandidate
 └─ strategyProfile
```

------------------------------------------------------------------------

# 5. Session

``` text
PRE_MARKET
OPENING
MORNING
LUNCH
AFTERNOON
CLOSING
AFTER_MARKET
```

세션은 시간만으로 결정된다.

------------------------------------------------------------------------

# 6. Market State

``` text
UNKNOWN

OPENING_BREAKOUT

TREND_UP

TREND_DOWN

RANGE

MEAN_REVERSION

VOLATILITY_EXPANSION

VOLATILITY_CONTRACTION

PANIC

RECOVERY

CLOSING_AUCTION
```

동시에 하나만 활성화된다.

------------------------------------------------------------------------

# 7. 상태 전이

``` text
OPENING

↓

OPENING_BREAKOUT

↓

TREND_UP

↓

RANGE

↓

AFTERNOON

↓

CLOSING_AUCTION
```

또는

``` text
TREND_UP

↓

PANIC

↓

RECOVERY
```

상태는 아무 때나 변경하지 않는다.

최소 유지시간(Min Duration)을 둔다.

------------------------------------------------------------------------

# 8. Strategy Profile

예시

``` python
{
 "state":"TREND_UP",
 "allowScalping":True,
 "allowSwing":True,
 "targetMultiplier":1.2,
 "stopMultiplier":1.0,
 "maxExposure":0.8
}
```

Strategy Engine은 Profile만 읽는다.

------------------------------------------------------------------------

# 9. 상태별 전략

  State              초단기   단기    중기   장기
  ------------------ -------- ------- ------ ------
  Opening Breakout   ★★★★★    ★★★★    ★      X
  Trend Up           ★★★★     ★★★★★   ★★★★   ★★
  Range              ★★       ★★★     ★★     ★
  Panic              X        X       ★      ★★
  Recovery           ★★★      ★★★★    ★★★    ★★

------------------------------------------------------------------------

# 10. 알고리즘

``` text
Market

+

Feature

+

Session

↓

State 계산

↓

Transition 검사

↓

Profile 생성

↓

Strategy 전달
```

------------------------------------------------------------------------

# 11. Data Contract

``` python
StateSnapshot = {
 "session":"MORNING",
 "marketState":"TREND_UP",
 "duration":52,
 "confidence":91,
 "profile":"TREND_PROFILE_V1",
 "updatedAt":"..."
}
```

------------------------------------------------------------------------

# 12. 테스트

-   장 시작 돌파
-   횡보장
-   급락
-   회복
-   VIX 급등
-   뉴스 충격
-   점심장
-   동시호가

------------------------------------------------------------------------

# 13. 구현 순서

1.  Session Manager
2.  State Classifier
3.  Transition Manager
4.  Profile Builder
5.  History Recorder
6.  Publisher

------------------------------------------------------------------------

# 14. 구현 원칙

-   점수(Score)가 아니라 상태(State)를 관리한다.
-   상태는 최소 유지시간을 가진다.
-   상태 전이는 로그를 남긴다.
-   Strategy는 상태를 직접 계산하지 않는다.
-   새로운 State는 Enum만 추가하면 된다.

------------------------------------------------------------------------

# 15. 쉬운 설명

State Engine은 사람으로 치면 **시장 분위기를 읽는 역할**이다.

예를 들어 오전 9시 5분에 거래량이 폭발하며 상승하면 같은 상승장이라도
'Opening Breakout'으로 본다. 오후 2시 40분이라면 같은 상승이라도
'Closing Auction'으로 해석한다.

가격만으로는 같은 차트처럼 보여도 시장의 의미는 다르다.

따라서 Strategy Engine은 직접 시장을 해석하지 않고, State Engine이
전달한 상태에 맞춰 행동만 바꾼다.

이 구조를 사용하면 새로운 전략을 추가해도 상태 판단 로직은 한 곳에서만
관리되므로 유지보수가 쉬워진다.
