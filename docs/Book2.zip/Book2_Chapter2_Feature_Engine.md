# Book 2 - Chapter 2

# Feature Engine 설계

## 목표

Data Layer가 수집한 원시 데이터를 모든 엔진이 동일한 방식으로 사용할 수
있는 Feature로 변환한다.

## 책임

-   Raw → Feature 변환
-   지표 계산
-   캐시 관리
-   동일 계산식 유지(백테스트/실시간)

## 입력

-   OHLCV
-   호가
-   체결
-   시장 데이터

## 출력

``` text
FeatureSnapshot
├── trend
├── momentum
├── volatility
├── volume
├── liquidity
└── market
```

## 핵심 Feature

### 추세

-   SMA
-   EMA
-   VWAP

### 모멘텀

-   RSI
-   ROC
-   MACD

### 변동성

-   ATR
-   Bollinger Width

### 거래량

-   RVOL
-   거래대금

### 유동성

-   Spread
-   Depth

## 설계 원칙

1.  Feature는 읽기 전용
2.  계산은 Feature Engine만 수행
3.  모든 엔진은 Feature만 사용
4.  동일 코드 사용으로 Train/Serve Skew 제거

## 예시

``` python
feature = {
    "symbol":"005930",
    "atr":820,
    "rvol":2.8,
    "vwap":71200,
    "spread":1,
    "confidence":94
}
```

## Claude Code 구현 순서

1.  feature_store.py
2.  indicator/
3.  snapshot 생성
4.  cache
5.  테스트

## 체크리스트

-   [ ] 동일 입력=동일 출력
-   [ ] 실시간/백테스트 동일
-   [ ] Feature 버전 관리
