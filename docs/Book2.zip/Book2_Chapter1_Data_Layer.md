# Book 2. 시스템 구현편

# Chapter 1. Data Layer

## 1. 목적

Data Layer는 시스템의 **유일한 데이터 원천(Source of Truth)** 이다. 모든
엔진은 Data Layer가 제공하는 데이터만 사용한다. 전략 엔진은 API를 직접
호출하지 않는다.

------------------------------------------------------------------------

## 2. 책임

-   거래소/API 데이터 수집
-   Raw 데이터 영구 보관
-   데이터 검증
-   정규화
-   Manifest 생성
-   Provenance 기록

Data Layer는 매수/매도 판단을 하지 않는다.

------------------------------------------------------------------------

## 3. 입력

### 시세

-   KIS
-   KRX
-   Yahoo Finance

### 재무

-   DART
-   SEC EDGAR

### 뉴스

-   공시
-   뉴스

------------------------------------------------------------------------

## 4. 출력

PriceBar

FinancialStatement

Disclosure

NewsEvent

MarketIndex

OptionChain

Manifest

------------------------------------------------------------------------

## 5. 데이터 계약

### PriceBarV1

``` text
ticker
datetime
open
high
low
close
volume
adjusted
requestedAt
source
```

필수 규칙

-   datetime은 UTC 또는 명확한 Timezone 포함
-   requestedAt 기록
-   source 기록
-   adjusted 기록

------------------------------------------------------------------------

## 6. 처리 순서

``` text
API

↓

Validate

↓

Normalize

↓

Store Raw

↓

Manifest 생성

↓

Feature Engine 전달
```

Raw는 절대 수정하지 않는다.

------------------------------------------------------------------------

## 7. Validation

반드시 검사

-   중복
-   결측
-   시간순서
-   거래일
-   Timezone
-   음수 가격
-   음수 거래량

검사 실패는 Manifest에 기록한다.

------------------------------------------------------------------------

## 8. Manifest

예시

``` json
{
  "date":"2026-08-08",
  "source":"KIS",
  "rows":125334,
  "missing":0,
  "duplicates":0,
  "hash":"..."
}
```

Manifest는 이후 엔진의 입력 검증 기준이다.

------------------------------------------------------------------------

## 9. Provenance

모든 데이터는 생성 이력을 남긴다.

기록

-   source
-   requestedAt
-   apiVersion
-   adjusted
-   timezone

------------------------------------------------------------------------

## 10. 구현 순서

1.  API Adapter
2.  Validator
3.  Normalizer
4.  Raw Storage
5.  Manifest Writer
6.  Provenance Writer

------------------------------------------------------------------------

## 11. 향후 확장

-   암호화폐 거래소
-   해외 선물
-   옵션
-   VIX
-   환율
-   거시경제 데이터

Data Contract는 변경하지 않고 Adapter만 추가한다.

------------------------------------------------------------------------

# 쉬운 설명

Data Layer는 공장의 원자재 창고이다.

잘못된 원자재가 들어오면 이후 모든 엔진이 잘못된 결과를 만든다.

따라서 Data Layer의 목표는 **빠른 수집이 아니라 신뢰할 수 있는
데이터**를 만드는 것이다.

핵심 원칙은 하나다.

> Raw는 보존하고, 계산은 이후 엔진에서 한다.

이 원칙이 있으면 새로운 지표가 필요해져도 데이터를 다시 받을 필요 없이
Feature만 다시 계산하면 된다.
