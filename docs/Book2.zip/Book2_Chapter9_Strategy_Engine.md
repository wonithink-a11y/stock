# Book 2 - Chapter 9

# Strategy Engine 설계

## 1. 목적

Strategy Engine은 시장 데이터를 분석하여 **매매 기회(Alpha)** 를
생성하는 엔진이다.

다른 엔진이 '거래 가능한 환경'을 만드는 역할이라면, Strategy Engine은
'무엇을 언제 사고 팔 것인가'를 결정한다.

------------------------------------------------------------------------

# 2. 책임

-   종목 분석
-   진입 신호 생성
-   청산 신호 생성
-   손절/목표가 제안
-   확률(Probability) 계산
-   기대값(Expectancy) 계산

매매 승인 여부는 Risk Engine이 결정한다.

------------------------------------------------------------------------

# 3. 입력

-   FeatureSnapshot
-   MarketSnapshot
-   StateSnapshot
-   EventSnapshot
-   ConfidenceSnapshot
-   UniverseSnapshot

------------------------------------------------------------------------

# 4. 출력

``` text
StrategySignal
├─ symbol
├─ strategy
├─ timeframe
├─ direction
├─ probability
├─ expectancy
├─ score
├─ entryPrice
├─ stopPrice
├─ targetPrice
└─ reason
```

------------------------------------------------------------------------

# 5. 공통 인터페이스

모든 전략은 동일한 인터페이스를 구현한다.

``` python
class Strategy:
    def analyze(feature_store) -> StrategySignal:
        ...
```

장기, 중기, 단기, 초단기 모두 같은 형식을 사용한다.

------------------------------------------------------------------------

# 6. 엔진 구성

-   LongTerm Strategy
-   MidTerm Strategy
-   ShortTerm Strategy
-   UltraShort Strategy

각 엔진은 독립적으로 실행된다.

------------------------------------------------------------------------

# 7. 평가 순서

``` text
Feature

↓

조건 검사

↓

Score 계산

↓

Probability 계산

↓

Expectancy 계산

↓

Signal 생성
```

------------------------------------------------------------------------

# 8. Probability

단순 점수가 아니라 상승 확률을 계산한다.

예시

-   0.42 : 거래 안 함
-   0.61 : 관심
-   0.74 : 후보
-   0.86 : 강한 신호

------------------------------------------------------------------------

# 9. Expectancy

``` text
EV =
(승률 × 평균수익)
-
(패배율 × 평균손실)
```

EV가 음수이면 신호를 폐기한다.

------------------------------------------------------------------------

# 10. Data Contract

``` python
StrategySignal={
 "symbol":"005930",
 "strategy":"SHORT_BREAKOUT",
 "timeframe":"SHORT",
 "direction":"LONG",
 "probability":0.78,
 "expectancy":1.43,
 "score":91,
 "entryPrice":72000,
 "stopPrice":70700,
 "targetPrice":74800
}
```

------------------------------------------------------------------------

# 11. 구현 원칙

-   Score만 출력하지 않는다.
-   Probability와 Expectancy를 함께 제공한다.
-   전략은 서로 독립적이다.
-   Feature만 읽고 직접 계산을 중복하지 않는다.

------------------------------------------------------------------------

# 12. 구현 순서

1.  Strategy Interface
2.  Long Strategy
3.  Mid Strategy
4.  Short Strategy
5.  Ultra Short Strategy
6.  Signal Validator
7.  Publisher

------------------------------------------------------------------------

# 13. 쉬운 설명

Strategy Engine은 시스템의 '아이디어 생성기'이다.

하지만 이 엔진은 혼자서 주문하지 않는다.

생성한 신호는 Confidence Engine에서 신뢰도를 검증하고, Risk Engine에서
위험을 평가하며, Portfolio Engine에서 계좌 전체 관점으로 다시 확인한
뒤에야 Execution Engine으로 전달된다.

따라서 Strategy Engine의 목표는 **많은 신호를 만드는 것**이 아니라,
**기대값이 높은 신호를 안정적으로 생성하는 것**이다.
