# 제1권 - Chapter 7. Portfolio Risk Engine

## 목적

Portfolio Risk Engine은 계좌 전체의 위험을 관리한다.

## 책임

-   최대 종목 비중
-   최대 섹터 비중
-   총 투자 비중
-   DLL
-   현금 비중
-   상관관계 제한

## 입력

Trade Proposal Portfolio State Market Score

## 처리

1.  Exposure 계산
2.  종목 비중 검사
3.  섹터 검사
4.  DLL 검사
5.  Cash Buffer 검사
6.  승인

## DLL

일일 손실 한도 초과 시 신규 진입을 중단한다.

## Correlation

동일 섹터 과집중을 방지한다.

## Cash Buffer

시장 위험이 높을수록 현금 비중을 높인다.

## 출력

Approved Final Position Size Reason

## 핵심 원칙

좋은 거래보다 계좌 생존이 우선이다.
