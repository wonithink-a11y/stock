# 제1권 Chapter 19. System Pipeline (전체 데이터 흐름)

## 목표

지금까지 설계한 모든 엔진을 하나의 데이터 파이프라인으로 연결한다.

이 장의 목적은 **"데이터가 어디에서 생성되고, 어떤 엔진을 거쳐, 어떤 결과가 만들어지는가"**를 명확하게 정의하는 것이다.

---

# 19.1 전체 파이프라인

```
Market Data
      │
      ▼
Data Engine
      │
      ▼
Feature Engine
      │
      ▼
Universe Engine
      │
      ▼
Market Engine
      │
      ▼
State Engine
      │
      ▼
Event Engine
      │
      ▼
Confidence Engine
      │
      ▼
Strategy Engine
      │
      ▼
Trade Risk Engine
      │
      ▼
Portfolio Risk Engine
      │
      ▼
Execution Engine
      │
      ▼
Broker(KIS)
      │
      ▼
Execution Report
      │
      ▼
Research Engine
```

---

# 19.2 Data Engine

수집 대상

- 가격
- 분봉
- 일봉
- 거래량
- 재무
- 뉴스
- 공시
- 투자자 수급
- 옵션
- VIX
- 암호화폐

출력

```
Raw Data
```

---

# 19.3 Feature Engine

Raw를 그대로 사용하지 않는다.

모든 Feature를 미리 계산한다.

예

- ATR
- RVOL
- VWAP
- 이동평균
- RSI
- ADR
- 변동성
- 모멘텀

출력

```
Feature Snapshot
```

---

# 19.4 Universe Engine

전체 종목을 대상으로 하지 않는다.

거래 가능 후보를 선정한다.

예

- 거래대금
- 시가총액
- 관리종목 제외
- 유동성
- 상장기간

출력

```
Universe Snapshot
```

---

# 19.5 Market / State / Event

세 엔진은 서로 역할이 다르다.

Market

시장 강도

State

현재 장세

Event

일정 위험

세 결과를 합쳐

Strategy가 사용할 환경을 만든다.

---

# 19.6 Strategy Engine

각 기간별 엔진은 독립이다.

- 초단기
- 단기
- 중기
- 장기

출력

```
Probability
Expectancy
Confidence
Target
Stop
```

---

# 19.7 Risk

Trade Risk

↓

Portfolio Risk

순서로 진행한다.

개별 종목과

계좌 전체를 분리한다.

---

# 19.8 Execution

Execution은

주문만 담당한다.

전략 판단은 하지 않는다.

FSM으로 관리한다.

---

# 19.9 Feedback

Execution 결과는

Research Engine으로 전달된다.

슬리피지

체결률

승률

손익비

Drawdown

을 지속적으로 학습한다.

---

# 19.10 Source of Truth

Source of Truth

- Broker
- Raw Data
- Feature Store

Projection

- Firebase RTDB
- Dashboard

---

# 19.11 CQRS

Write

Engine

↓

Broker

↓

Event Log

Read

Dashboard

↓

RTDB

명령과 조회를 분리한다.

---

# 19.12 핵심 원칙

1. 데이터는 한 방향으로 흐른다.
2. 엔진은 Contract만 의존한다.
3. Raw는 변경하지 않는다.
4. Feature를 공유한다.
5. Strategy는 확률을 계산한다.
6. Risk는 생존을 보장한다.
7. Execution은 안전하게 주문한다.
8. Research는 시스템을 진화시킨다.

---

## Chapter Summary

이 장은 시스템 전체의 데이터 흐름을 정의하였다.

이후 Chapter 20에서는 지금까지 설계한 내용을 실제 Claude Code 프로젝트로 구현하기 위한 개발 로드맵과 우선순위를 설명한다.
