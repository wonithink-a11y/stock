# 제1권 Chapter 2. 데이터(Data Layer)

## 역할

모든 엔진의 유일한 입력을 제공한다.

## 데이터 종류

-   시세(OHLCV)
-   분봉
-   재무
-   수급
-   뉴스
-   이벤트
-   파생지표 원천

## 원칙

-   Raw는 수정하지 않는다.
-   Feature는 Raw에서 생성한다.
-   Backtest와 Live가 동일한 Feature를 사용한다.

## 파이프라인

Raw → Validation → Feature Store → Engine

## 실패 처리

-   결측 기록
-   재시도 정책
-   Provenance 저장
-   Manifest 생성

## 요약

데이터 계층은 가장 단순해야 하며, 모든 계산의 출발점이다.
