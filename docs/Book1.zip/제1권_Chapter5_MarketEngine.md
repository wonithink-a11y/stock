# 제1권 - Chapter 5. Market Engine

## 목적

Market Engine은 시장 전체의 상태를 판단하여 모든 전략 엔진에 공통 기준을
제공한다.

## 핵심 책임

-   상승장/하락장 판별
-   시장 위험도 계산
-   최대 투자 비중 결정
-   Kill Switch 제공

## 입력 데이터

-   KOSPI/KOSDAQ
-   S&P500/NASDAQ
-   ADR
-   VIX
-   외국인/기관 수급
-   프로그램 매매

## 출력

-   Market State
-   Market Score (0\~100)
-   Risk Level
-   Max Exposure

## Kill Switch

시장 위험이 일정 수준 이상이면 신규 진입을 중단한다.

## Exposure

Market Score가 높을수록 최대 투자 비중을 높인다.

## 세션 상태

Opening Morning Lunch Afternoon Closing

## Strategy와 관계

Strategy는 종목을 선택한다. Market Engine은 매매 가능 여부를 결정한다.

## 하지 않는 일

-   종목 선정
-   주문 실행
-   손절 계산

## 핵심 원칙

좋은 종목보다 좋은 시장이 먼저다.
