# 제1권 Chapter 1. 시스템 철학

## 목적

이 시스템은 예측 시스템이 아니라 확률 기반 의사결정 시스템이다.

## 핵심 원칙

1.  Score와 Confidence를 분리한다.
2.  기대값(Expected Value)이 0보다 큰 거래만 수행한다.
3.  시장(Market), 전략(Strategy), 리스크(Risk)를 분리한다.
4.  모든 엔진은 데이터 계약(Data Contract)으로만 통신한다.

## 데이터 흐름

Data → Feature → Universe → Market → Strategy → Risk → Portfolio →
Execution → Research

## 설계 규칙

-   엔진 간 내부 구현을 공유하지 않는다.
-   Feature는 한 번 계산하고 여러 엔진이 읽는다.
-   Execution만 주문 권한을 가진다.
-   로그는 모든 상태 전이를 기록한다.

## 요약

좋은 시스템은 승률이 아니라 기대값과 리스크 관리로 장기 생존을 만든다.
