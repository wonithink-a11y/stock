# 제1권 Chapter 20. Claude Code 구현 로드맵

## 목표

이 장은 제1권에서 설계한 시스템을 실제 코드 프로젝트로 구현하기 위한 개발 순서를 정의한다.

## 20.1 구현 원칙

- Data Contract를 먼저 확정한다.
- 엔진보다 데이터 파이프라인을 먼저 만든다.
- Feature를 한 곳에서 계산한다.
- 각 엔진은 Contract만 의존한다.
- 백테스트와 실전이 같은 코드를 사용한다.

## 20.2 권장 개발 순서

1. Data Contract
2. Feature Store
3. Data Engine
4. Universe Engine
5. Market Engine
6. State / Event Engine
7. Strategy Engine
8. Risk Engine
9. Portfolio Engine
10. Execution Engine
11. Research Engine

## 20.3 디렉터리 예시

```text
contracts/
engines/
features/
research/
execution/
portfolio/
risk/
market/
state/
event/
tests/
docs/
```

## 20.4 구현 단계

### Phase 1
- 데이터 수집
- Feature 생성
- 백테스트

### Phase 2
- 실시간 엔진
- 모니터링
- 주문 시뮬레이션

### Phase 3
- KIS API
- 자동 주문
- 운영

## 20.5 체크리스트

- Contract Versioning
- Logging
- Event Log
- Idempotency
- Retry
- Monitoring
- Metrics
- Replay
- Recovery

## Chapter Summary

설계는 여기서 끝난다.
제2권부터는 실제 구현(Implementation)을 시작한다.
