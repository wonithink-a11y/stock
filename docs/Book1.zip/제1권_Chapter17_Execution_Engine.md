# 제1권 Chapter 17. Execution Engine

## 목표

Execution Engine은 Strategy Engine이 생성한 매매 신호를 실제 주문으로 변환하고,
주문의 생성부터 체결 완료까지 모든 상태를 관리하는 엔진이다.

자동매매 시스템에서 가장 높은 신뢰성이 요구되는 계층이며,
단 한 번의 오류도 실제 자산 손실로 이어질 수 있다.

---

# 17.1 책임

Execution Engine의 책임은 다음과 같다.

- 주문 생성
- 주문 전송
- 주문 상태 관리(FSM)
- 부분 체결 관리
- 주문 정정 및 취소
- 재시도(Retry)
- 장애 복구(Recovery)
- Broker API(KIS 등) 연동

Execution Engine은 전략을 판단하지 않는다.
오직 "어떻게 안전하게 주문을 실행할 것인가"만 책임진다.

---

# 17.2 입력

Execution Engine은 다음 Contract를 입력으로 받는다.

```
Strategy Signal
Portfolio Decision
Risk Policy
Current Position
Current Cash
Broker Status
```

---

# 17.3 출력

```
Order Request
Order Event
Fill Event
Cancel Event
Execution Report
```

---

# 17.4 주문 상태(FSM)

주문은 반드시 상태(State)를 가진다.

```
NEW
 ↓
VALIDATED
 ↓
SUBMITTED
 ↓
ACKNOWLEDGED
 ↓
PARTIAL_FILLED
 ↓
FILLED

또는

CANCEL_REQUESTED
 ↓
CANCELED

또는

REJECTED
FAILED
EXPIRED
```

모든 상태 전이는 Event Log로 기록한다.

---

# 17.5 멱등성(Idempotency)

같은 주문이 두 번 실행되는 것은 치명적인 사고다.

모든 주문은 고유한 Order UUID를 가진다.

예)

```
ORDER-20260808-000001
```

동일 UUID의 주문은 한 번만 처리한다.

---

# 17.6 Retry 정책

네트워크 오류 발생 시

무조건 재주문하지 않는다.

우선 수행

1. Broker 상태 조회
2. 주문 존재 여부 확인
3. 존재하면 상태 동기화
4. 없을 경우에만 재시도

---

# 17.7 Ghost Order

가장 위험한 장애

```
주문은 접수됨
↓
응답은 받지 못함
```

이 경우

다시 주문을 보내면

중복 주문이 된다.

따라서

상태 조회 후 복구한다.

---

# 17.8 부분 체결

예)

100주 주문

↓

40주 체결

↓

30주 체결

↓

30주 체결

Execution Engine은

잔량을 계속 관리해야 한다.

---

# 17.9 슬리피지

실제 체결가는

신호 가격과 다르다.

반드시 기록

- Signal Price
- Order Price
- Fill Price

슬리피지 통계를 지속적으로 저장한다.

---

# 17.10 Broker 추상화

Execution Engine은

KIS만 알면 안 된다.

```
Execution

↓

Broker Interface

↓

KIS
KRX
Crypto
Interactive Brokers
```

Broker Adapter 구조를 사용한다.

---

# 17.11 장애 복구

프로세스 재시작 시

Broker API를 조회하여

현재

- 잔고
- 미체결
- 체결

상태를 다시 구성한다.

Firebase는 모니터링용이며

Source of Truth가 아니다.

---

# 핵심 원칙

1. 주문은 상태 머신으로 관리한다.
2. 같은 주문은 두 번 실행하지 않는다.
3. 장애 시 재주문보다 상태 복구를 우선한다.
4. Broker는 추상화한다.
5. 실시간 주문보다 안정성이 우선이다.
