# 제1권 - Chapter 6. Trade Risk Engine

## 목적

Trade Risk Engine은 개별 거래의 위험을 관리하는 엔진이다.

## 책임

-   진입 승인
-   손절가 계산
-   목표가 계산
-   손익비 계산
-   기대값 계산
-   포지션 크기 결정

## 입력

Strategy Engine - entry_price - confidence - probability_up

Feature Store - ATR - RVOL - VWAP - Spread

Market Engine - Market Score - Max Exposure

## 손절

고정 손절 대신 ATR 기반 손절을 사용한다.

Stop = Entry - (ATR × Multiplier)

## 목표가

Target = Entry + (ATR × RewardMultiplier)

## 기대값

Expectancy = WinRate×AvgWin - LoseRate×AvgLoss

기대값이 음수이면 거래하지 않는다.

## 포지션

Half Kelly를 기본으로 사용하며 최대 비중은 Clamp로 제한한다.

## 거부 조건

-   Spread 과다
-   RVOL 부족
-   Confidence 부족
-   Kill Switch

## 출력

Approved Stop Price Target Price Position Size Expected Value

## 핵심 원칙

수익보다 먼저 손실을 통제한다.
