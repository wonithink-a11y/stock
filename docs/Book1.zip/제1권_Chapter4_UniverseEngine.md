# 제1권 - Chapter 4. Universe Engine

## 목적

Universe Engine은 분석 대상 종목을 결정하는 계층이다.

## 왜 필요한가

-   전체 종목을 항상 분석하지 않는다.
-   CPU와 메모리를 절약한다.
-   실시간성을 확보한다.

## 데이터 흐름

Raw → Feature Store → Universe Engine → Strategy

## 기본 필터

-   거래정지
-   관리종목
-   ETF/ETN
-   우선주
-   SPAC(전략 선택)

## 유동성

평균 거래대금과 거래량을 이용해 필터링한다.

## 시가총액

초단기·단기·중기·장기 엔진별 Universe는 다를 수 있다.

## Dynamic Universe

매일 또는 매주 Universe를 자동 갱신한다.

## Watch List

Universe는 분석 대상이고 Watch List는 실시간 감시 대상이다.

## PIT

백테스트는 당시 존재했던 Universe만 사용한다.

## 출력

symbol market sector liquidity_grade universe_version

## 핵심 원칙

Universe는 투자 대상을 추천하는 엔진이 아니라 분석 대상을 결정하는
엔진이다.
