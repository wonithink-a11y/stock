# 제1권 Chapter 18. Data Contract

## 목표

Data Contract는 모든 엔진이 서로 데이터를 주고받는 공통 규약이다.

전략의 내부 구현은 자유롭게 변경할 수 있지만, Data Contract는 버전 관리되는 불변 인터페이스여야 한다.

> Engine은 서로의 코드를 알지 못한다.
> 오직 Contract만 이해한다.

---

# 18.1 왜 필요한가

계약이 없으면

- 필드 이름 변경
- 자료형 변경
- 단위 불일치
- 누락 데이터

같은 문제가 연쇄적으로 발생한다.

Data Contract는 이러한 문제를 사전에 차단한다.

---

# 18.2 기본 원칙

모든 Engine은

입력(Input)

↓

처리(Process)

↓

출력(Output)

의 형태를 가진다.

입출력은 모두 Contract를 따른다.

---

# 18.3 주요 Contract

시스템은 다음 Contract를 사용한다.

```
MarketState
FeatureSnapshot
UniverseSnapshot
StrategySignal
RiskDecision
PortfolioDecision
OrderRequest
ExecutionReport
PositionSnapshot
AccountSnapshot
ResearchResult
```

---

# 18.4 Strategy Signal 예시

```
StrategySignal

symbol

strategy

timeframe

probability_up

expectancy

confidence

target_price

stop_price

generated_at
```

Score만 전달하지 않는다.

확률과 기대값을 함께 전달한다.

---

# 18.5 Risk Decision

Risk Engine은

```
allow

position_size

max_loss

stop_price

risk_score
```

를 반환한다.

Strategy는 주문 수량을 결정하지 않는다.

---

# 18.6 Portfolio Decision

Portfolio Engine은

```
approved

cash_required

sector_weight

portfolio_risk

reason
```

을 반환한다.

---

# 18.7 Order Request

Execution Engine으로 전달되는 최종 주문

```
order_id

symbol

side

quantity

price

order_type

time_in_force

generated_at
```

---

# 18.8 Version

모든 Contract는 Version을 가진다.

예)

```
StrategySignal.v1

StrategySignal.v2
```

기존 Engine을 깨뜨리지 않는다.

---

# 18.9 Validation

모든 Contract는

생성 즉시 검증한다.

예)

- symbol 존재
- confidence 0~100
- quantity > 0
- probability 0~1

Validation 실패 시 다음 Engine으로 전달하지 않는다.

---

# 18.10 Pydantic

Python 구현에서는

Pydantic Model을 표준으로 사용한다.

장점

- 타입 검증
- 범위 검증
- JSON 직렬화
- 자동 문서화

---

# 18.11 Contract 변경 정책

Contract는 가능한 변경하지 않는다.

변경이 필요하면

1. 새 Version 생성
2. 구 Version 유지
3. Migration 기간 운영
4. 구 Version 제거

---

# 핵심 원칙

1. Engine은 Contract만 의존한다.
2. Contract는 버전 관리한다.
3. Validation 없는 Contract는 허용하지 않는다.
4. Strategy와 Execution은 직접 연결하지 않는다.
5. Contract 안정성이 시스템 안정성이다.
