# 제1권 - Chapter 9. Strategy Engine

## 목적

Strategy Engine은 시스템의 알파(Alpha)를 생성하는 핵심 엔진이다.

Market Engine이 "지금 매매해도 되는 시장인가?"를 판단하고, Risk Engine이
"얼마를 투자할 것인가?"를 결정한다면, Strategy Engine은 **무엇을, 언제,
왜 매매할 것인가**를 결정한다.

------------------------------------------------------------------------

# 핵심 원칙

Strategy Engine은 점수(Score)를 만드는 엔진이 아니다.

반드시 다음 5가지를 동시에 출력한다.

-   Probability (상승 확률)
-   Expected Return
-   Expected Loss
-   Expectancy
-   Return Distribution

------------------------------------------------------------------------

# Strategy 종류

## 장기

보유기간 6개월 \~ 수년

데이터

-   재무
-   밸류에이션
-   산업 성장
-   ROE
-   FCF
-   부채
-   기관 보유

목표

복리 성장

------------------------------------------------------------------------

## 중기

보유기간

1\~6개월

데이터

-   실적 개선
-   수급
-   추세
-   실적 발표
-   EPS Revision

------------------------------------------------------------------------

## 단기

보유기간

수일 \~ 수주

데이터

-   돌파
-   RVOL
-   VWAP
-   거래대금
-   뉴스
-   공시

------------------------------------------------------------------------

## 초단기

보유기간

수분 \~ 당일

데이터

-   Tick
-   Order Book
-   Spread
-   체결강도
-   VWAP
-   RVOL

------------------------------------------------------------------------

# 공통 입력

Feature Store

Market State

Universe

Confidence

Portfolio State

------------------------------------------------------------------------

# 공통 출력

Signal V1

symbol

strategy

probability

expectancy

confidence

entry

stop

target

holding_period

generated_at

------------------------------------------------------------------------

# Entry Rule

전략마다 다르지만

다음 조건을 모두 만족해야 한다.

-   Market 승인
-   Risk 승인
-   Confidence 승인
-   Portfolio 승인

------------------------------------------------------------------------

# Exit Rule

청산 이유는 반드시 기록한다.

-   Stop Loss
-   Target
-   Time Exit
-   Trailing Stop
-   Strategy Exit
-   Market Exit

------------------------------------------------------------------------

# Strategy Plugin

모든 전략은 동일 인터페이스를 구현한다.

evaluate()

backtest()

validate()

metadata()

새 전략은 Plugin 등록만으로 추가 가능해야 한다.

------------------------------------------------------------------------

# 백테스트

동일 Feature

동일 Strategy

동일 Contract

동일 Risk

실시간과 완전히 동일한 로직을 사용한다.

------------------------------------------------------------------------

# 하지 않는 일

주문 실행

포지션 계산

시장 상태 계산

------------------------------------------------------------------------

# Claude Code 구현 체크리스트

-   Strategy Base Class
-   Long Engine
-   Mid Engine
-   Swing Engine
-   Scalping Engine
-   Plugin Loader
-   Signal Contract
-   Unit Test

------------------------------------------------------------------------

# 핵심 원칙

좋은 전략은

승률이 높은 전략이 아니다.

기대값(Expected Value)이

지속적으로 양수인 전략이다.

Strategy Engine의 목표는

예측이 아니라

장기적으로 양(+)의 기대값을 반복적으로 생산하는 것이다.
