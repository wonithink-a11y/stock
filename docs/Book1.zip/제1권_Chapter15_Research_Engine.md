# 제1권 Chapter 15. Research Engine

## 목표

Research Engine은 **실시간 매매와 완전히 분리된 연구 환경**이다.
역할은 새로운 알파를 발견하고, 기존 전략의 성능 저하(Alpha Decay)를 감지하며,
실거래 결과를 기반으로 전략을 지속적으로 개선하는 것이다.

> Research Engine은 주문을 실행하지 않는다.
> 오직 분석과 검증만 수행한다.

---

# 15.1 책임

- 전략 아이디어 검증
- Feature 중요도 분석
- 파라미터 최적화
- Walk-Forward Validation
- Monte Carlo 분석
- Alpha Decay 감시
- 전략 버전 관리

---

# 15.2 입력 데이터

```
Raw Data
Feature Store Snapshot
Signal History
Order History
Execution Log
Portfolio History
Market Regime History
```

실시간 데이터를 직접 사용하지 않는다.

---

# 15.3 출력

```
Research Report
Strategy Version
Parameter Set
Feature Importance
Performance Metrics
```

---

# 15.4 평가 지표

- CAGR
- MDD
- Sharpe Ratio
- Sortino Ratio
- Profit Factor
- Win Rate
- Expectancy
- Average Holding Period
- Turnover
- Capacity

승률 하나만으로 전략을 평가하지 않는다.

---

# 15.5 Walk-Forward Validation

1. 학습 구간 선택
2. 파라미터 생성
3. 미래 구간 검증
4. 반복
5. 평균 성능 계산

미래 데이터를 이용한 최적화는 금지한다(PIT 방지).

---

# 15.6 Alpha Decay

다음을 지속적으로 모니터링한다.

- 승률 변화
- Expectancy 변화
- 거래 빈도
- 슬리피지 증가
- 평균 보유기간 변화

성능이 임계값 아래로 떨어지면 전략을 비활성화 후보로 표시한다.

---

# 15.7 Feature Selection

Feature는 추가보다 제거가 중요하다.

평가 기준

- 예측력
- 안정성
- 계산 비용
- 데이터 품질

---

# 15.8 Strategy Version

각 전략은 불변 버전으로 관리한다.

```
strategy:
  name: breakout_short
  version: 2.1.0
```

실거래 결과는 항상 버전과 연결한다.

---

# 15.9 Research Engine과 실시간 엔진 분리

```
Research
    ↓
Strategy Version

실시간 Engine
    ↓
주문
```

연구 코드가 실시간 시스템을 직접 변경해서는 안 된다.

---

# 핵심 원칙

1. 연구와 운영은 분리한다.
2. 백테스트보다 실거래 결과를 더 신뢰한다.
3. 승률보다 기대값을 우선한다.
4. 미래 데이터는 절대 사용하지 않는다.
5. 모든 전략은 버전 관리한다.
