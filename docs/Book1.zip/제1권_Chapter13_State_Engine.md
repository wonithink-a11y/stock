# 제1권 - Chapter 13. State Engine

## 목적

State Engine은 시스템 전체의 현재 상태(Single Source of State)를
관리하는 엔진이다.

각 엔진이 동일한 시장을 서로 다르게 해석하는 것을 방지하며, 모든 엔진이
하나의 상태를 공유하도록 한다.

------------------------------------------------------------------------

# 핵심 원칙

State는 데이터를 저장하는 것이 아니다.

현재 시스템이 어떤 환경에 있는지를 표현하는 것이다.

------------------------------------------------------------------------

# 책임

-   Market State 관리
-   Session State 관리
-   Portfolio State 관리
-   Event State 반영
-   State Transition 관리
-   Snapshot 생성
-   Recovery 지원

------------------------------------------------------------------------

# State의 종류

## 1. Market State

-   Bull
-   Neutral
-   Bear
-   Panic
-   Recovery

------------------------------------------------------------------------

## 2. Session State

-   Pre-Market
-   Opening
-   Morning
-   Lunch
-   Afternoon
-   Closing Auction
-   After Market

------------------------------------------------------------------------

## 3. Portfolio State

-   Normal
-   Defensive
-   Capital Protection
-   Trading Halt

------------------------------------------------------------------------

## 4. System State

-   Healthy
-   Warning
-   Degraded
-   Recovery
-   Emergency Stop

------------------------------------------------------------------------

# State Transition

State는 자유롭게 변경되지 않는다.

반드시 Transition Rule을 거친다.

예)

Bull

↓

Neutral

↓

Bear

↓

Panic

↓

Recovery

↓

Bull

Transition은 Event Log에 모두 기록한다.

------------------------------------------------------------------------

# State Snapshot

일정 주기마다 현재 상태를 저장한다.

예)

-   Timestamp
-   Market State
-   Session State
-   Portfolio State
-   System State
-   Version

Snapshot은 Recovery 시 참고 자료로만 사용한다.

------------------------------------------------------------------------

# 데이터 흐름

Data Layer

↓

Feature Store

↓

Market Engine

↓

Event Engine

↓

State Engine

↓

Strategy Engine

↓

Portfolio Engine

↓

Execution Engine

State Engine은 중앙 허브 역할을 수행한다.

------------------------------------------------------------------------

# Recovery

프로그램 재시작 시

1.  Broker 상태 조회
2.  Market 상태 계산
3.  Portfolio 상태 계산
4.  Event 상태 확인
5.  새로운 State 생성

RTDB는 Recovery 기준이 아니다.

Broker와 계산 결과가 기준이다.

------------------------------------------------------------------------

# State Contract

필수 필드

-   State ID
-   Version
-   Timestamp
-   Market State
-   Session State
-   Portfolio State
-   System State
-   Source
-   Reason

------------------------------------------------------------------------

# 상태 변경 원칙

State는 직접 수정하지 않는다.

반드시 Event 또는 Engine의 판단을 통해 변경한다.

모든 변경은 추적 가능해야 한다.

------------------------------------------------------------------------

# Claude Code 구현 체크리스트

-   State Contract
-   State Manager
-   Transition Validator
-   Snapshot Manager
-   Recovery Builder
-   State Logger
-   State Broadcaster

------------------------------------------------------------------------

# 향후 확장

State Engine은

-   국내주식
-   미국주식
-   VIX
-   암호화폐
-   ETF

모든 자산군이 공통으로 사용하는 엔진이다.

전략마다 State를 따로 만들지 않는다.

------------------------------------------------------------------------

# 핵심 원칙

State는 진실(Source of Truth)이 아니다.

State는 현재 시스템의 해석 결과이다.

진실은 항상

-   시장 데이터
-   Broker API
-   Portfolio 데이터

에서 다시 계산할 수 있어야 한다.
