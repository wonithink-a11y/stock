# 제1권 Chapter 16. Backtest Engine

## 목표

Backtest Engine은 과거 데이터를 이용하여 전략의 성능을 검증하는 엔진이다.

핵심 목적은 **좋은 결과를 만드는 것**이 아니라 **실전과 최대한 동일한 환경을 재현하는 것**이다.

---

# 16.1 역할

- 전략 검증
- 기대값 측정
- 리스크 측정
- 파라미터 비교
- 실전 투입 여부 결정

Backtest는 Research Engine의 하위 도구이며 실시간 주문을 생성하지 않는다.

---

# 16.2 입력

```
Price Data (PIT)
Feature Store Snapshot
Market State
Strategy Version
Risk Policy
Portfolio Policy
```

모든 데이터는 당시 시점(Point-in-Time) 기준이어야 한다.

---

# 16.3 반드시 방지해야 하는 오류

## Look-ahead Bias

미래 데이터를 사용하는 오류.

예)

- 미래 재무제표
- 미래 종가
- 미래 거래량

실전에서는 알 수 없는 정보는 절대 사용하지 않는다.

---

## Survivorship Bias

현재 살아남은 종목만 사용하는 오류.

반드시

- 상장폐지
- 거래정지
- 관리종목

까지 포함한다.

---

## Data Snooping

같은 데이터를 반복 최적화하여 우연한 결과를 전략으로 착각하는 오류.

Walk-Forward Validation으로 방지한다.

---

# 16.4 체결 시뮬레이션

주문은 즉시 체결되지 않는다.

반영 항목

- 슬리피지
- 거래수수료
- 거래세
- 호가 스프레드
- 부분체결

---

# 16.5 비용 모델

총손익

```
Gross PnL
- Commission
- Tax
- Slippage
- Borrow Cost(공매도)
= Net PnL
```

평가는 항상 Net 기준으로 한다.

---

# 16.6 Portfolio Simulation

동시에 여러 종목을 보유한다.

관리 대상

- 현금
- 포지션
- 섹터 비중
- 최대 보유 종목
- DLL(Daily Loss Limit)

---

# 16.7 성능 평가

필수 지표

- CAGR
- MDD
- Sharpe
- Sortino
- Profit Factor
- Expectancy
- Recovery Factor
- Win Rate

Win Rate만으로 전략을 평가하지 않는다.

---

# 16.8 결과 저장

```
Run
 ├─ Parameters
 ├─ Trades
 ├─ Equity Curve
 ├─ Metrics
 └─ Logs
```

모든 결과는 재현 가능해야 한다.

---

# 16.9 실전 승인 기준

전략은 다음을 만족해야 한다.

- PIT 검증 통과
- Survivorship Bias 없음
- 거래비용 반영
- Walk-Forward 통과
- Monte Carlo 안정성 확보

---

# 핵심 원칙

1. 백테스트는 실전보다 보수적이어야 한다.
2. 미래 데이터를 절대 사용하지 않는다.
3. 모든 거래 비용을 반영한다.
4. 재현 가능한 결과만 신뢰한다.
5. 좋은 백테스트보다 좋은 실거래가 중요하다.
