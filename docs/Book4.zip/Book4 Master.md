BOOK4_MASTER.md

Book 4 — Short-Term & Ultra-Short-Term Trading System

1. Document Role

Book 4는 Book 1~3에서 구축한 투자 시스템을 기반으로 단기 및 초단기 투자 영역으로 확장하는 설계 문서다.

Book 4는 기존 시스템을 처음부터 다시 설계하지 않는다.

Book 1
투자 판단 원리
        ↓
Book 2
시스템 아키텍처
        ↓
Book 3
구현 / 검증 / 운영
        ↓
Book 4
단기 / 초단기 확장

Book 4의 핵심 질문:

중장기 투자 시스템을
단기 및 초단기 의사결정 시스템으로
어떻게 확장할 것인가?

---

2. Book 4의 목적

Book 4의 목표는 단순히 "단기 매매 전략"을 추가하는 것이 아니다.

기존 시스템이 사용하는:

Data
Feature
Score
Confidence
Signal
Action
Risk
Execution

구조를 단기·초단기 시간축에서도 사용할 수 있도록 확장한다.

핵심:

Long / Mid Term
        ↓
Short Term
        ↓
Ultra-Short Term

---

3. 가장 중요한 설계 원칙

Book 4에서 기존 시스템을 함부로 변경하지 않는다.

기본 원칙:

기존 Core
+
새로운 Time Horizon
+
새로운 Feature
+
새로운 Signal
+
새로운 Execution Requirement

이다.

즉:

기존 시스템을 버리고
단기 시스템을 새로 만드는 것

이 아니다.

---

4. Time Horizon

Book 4는 최소 세 가지 시간축을 구분한다.

MID/LONG
수개월 ~ 수년

SHORT
수일 ~ 수주

ULTRA-SHORT
수초 ~ 수시간

실제 경계값은 Chapter에서 데이터 특성과 시장별 차이를 고려하여 확정한다.

---

5. Time Horizon Independence

각 시간축은 독립적으로 판단할 수 있어야 한다.

Long Score
Short Score
Ultra-Short Score

를 동일 Score로 억지로 통합하지 않는다.

예:

Long = BUY
Short = HOLD
Ultra-Short = SELL

은 정상적인 상태다.

---

6. Multi-Horizon Architecture

최종 구조:

                     ┌───────────────┐
                     │   Market Data │
                     └───────┬───────┘
                             │
          ┌──────────────────┼──────────────────┐
          ↓                  ↓                  ↓
      Long/Mid             Short          Ultra-Short
          │                  │                  │
          ↓                  ↓                  ↓
       Features           Features           Features
          │                  │                  │
          ↓                  ↓                  ↓
        Score              Score              Score
          │                  │                  │
          ↓                  ↓                  ↓
       Signal             Signal             Signal
          └──────────────────┼──────────────────┘
                             ↓
                    Portfolio / Risk
                             ↓
                         Execution

---

7. Core vs Horizon Layer

Book 4에서 가장 중요한 구조적 구분:

CORE
=
공통 시스템

HORIZON
=
시간축별 판단

Core:

Data Contract
Feature Contract
Score Contract
Risk Contract
Execution Contract
Versioning
Monitoring
Audit

Horizon:

Long
Short
Ultra-Short

---

8. 단기 시스템의 핵심 변화

단기에서는 중장기보다 다음 요소의 중요도가 증가한다.

Price Action
Momentum
Volatility
Volume
Liquidity
Market Regime
Sector Rotation
Event
Flow

---

9. 초단기 시스템의 핵심 변화

초단기에서는 추가적으로:

Tick / Intraday Data
Order Flow
Bid / Ask
Spread
Depth
Trade Intensity
Volume Imbalance
Short-Term Volatility
Execution Latency

등을 고려할 수 있다.

단, 실제 Feature 채택 여부는 데이터 가용성과 검증 결과를 기준으로 결정한다.

---

10. Data Frequency

Book 4에서는 시간축에 따라 데이터 주기를 구분한다.

Daily
Hourly
15m
5m
1m
Tick

모든 시스템이 모든 주기를 사용하는 것은 아니다.

---

11. Data Explosion Control

초단기 데이터는 데이터량이 급격하게 증가한다.

따라서:

Raw Tick
     ↓
Aggregation
     ↓
Feature
     ↓
Storage

구조를 사용한다.

불필요한 Tick 데이터를 영구적으로 저장하는 것을 기본값으로 하지 않는다.

---

12. Intraday Data Contract

Intraday 데이터도 기존 Data Contract 원칙을 따른다.

최소:

symbol
timestamp
open
high
low
close
volume
source
availableAt
quality
version

을 관리한다.

---

13. Timestamp Principle

초단기 시스템에서는 Timestamp가 핵심이다.

다음 시간을 구분한다.

Event Time
Exchange Time
Receipt Time
Processing Time
Decision Time
Execution Time

이들을 하나의 timestamp로 통합하지 않는다.

---

14. Intraday PIT

초단기에서도 미래정보 차단 원칙을 유지한다.

data.availableAt <= decisionTime

을 만족해야 한다.

초단기 시스템에서 timestamp 오류는 일반적인 PIT 오류보다 더 위험할 수 있다.

---

15. Market Microstructure

Book 4에서는 필요에 따라 시장 미시구조를 도입한다.

대상:

Bid
Ask
Spread
Depth
Trade
Order Flow
Liquidity
Imbalance

단, 단순한 지표 추가가 목적이 아니다.

실제 의사결정에 추가적인 정보가 있는지 검증하는 것이 목적이다.

---

16. Short-Term Feature Layer

단기 Feature는 기존 Feature Store와 분리된 Namespace를 사용할 수 있다.

예:

feature/
├── fundamental/
├── valuation/
├── technical/
├── flow/
├── short/
└── intraday/

---

17. Feature Lifecycle

모든 Feature:

Research
 ↓
Validation
 ↓
Replay
 ↓
Paper
 ↓
Production

순서를 따른다.

Research Feature를 즉시 Production에 사용하지 않는다.

---

18. Signal Horizon

Signal도 시간축을 가진다.

signal.horizon

예:

LONG
SHORT
ULTRA_SHORT

Signal은 서로 독립적으로 생성할 수 있다.

---

19. Signal Conflict

서로 다른 시간축의 Signal이 충돌할 수 있다.

예:

LONG       BUY
SHORT      BUY
ULTRA      SELL

이를 오류로 처리하지 않는다.

Portfolio Policy가 최종 판단한다.

---

20. Multi-Horizon Decision

최종 의사결정:

Long Signal
+
Short Signal
+
Ultra-Short Signal
+
Portfolio State
+
Risk

를 고려할 수 있다.

단, 단기 Signal이 장기 투자 Thesis를 자동으로 무효화하지 않도록 한다.

---

21. Regime

단기 시스템에서는 Market Regime의 중요성이 증가한다.

예:

TREND
RANGE
HIGH_VOL
LOW_VOL
RISK_ON
RISK_OFF

Regime은 Signal의 Context로 사용한다.

---

22. Event Driven Short-Term

단기에서는 Event가 중요해진다.

예:

Earnings
Guidance
Disclosure
Macro Data
Policy
Sector Event
Company Event

Event 발생 시:

Event
 ↓
Re-evaluation
 ↓
Signal
 ↓
Risk

구조를 사용할 수 있다.

---

23. Event Latency

Event 시스템에서는:

Publication Time
Receipt Time
Processing Time
Decision Time

을 구분한다.

Event가 실제 시장에 알려진 시점을 정확히 관리해야 한다.

---

24. Volatility

단기/초단기에서는 Volatility를 단순 Feature가 아니라 Risk 변수로도 사용한다.

Volatility
→ Signal

뿐 아니라:

Volatility
→ Position Size
→ Risk Limit

으로 연결할 수 있다.

---

25. Liquidity

단기/초단기에서는 Liquidity가 실행 가능성을 결정한다.

최소 고려:

Volume
Turnover
Spread
Depth
Slippage

---

26. Slippage

Backtest에서 실제 Execution을 과대평가하지 않도록 한다.

최소:

Expected Price
+
Spread
+
Slippage
+
Fee

를 고려한다.

---

27. Transaction Cost

단기 매매에서는 거래비용의 영향이 커진다.

Gross Return
-
Fee
-
Tax
-
Spread
-
Slippage
=
Net Return

을 사용한다.

실제 시장별 비용 정책은 별도 Policy로 관리한다.

---

28. Execution Optimization

Book 3의 Execution이:

안전한 실행

에 초점을 맞췄다면,

Book 4에서는 추가적으로:

좋은 가격
낮은 Slippage
낮은 Market Impact
빠른 Execution

을 고려한다.

단, Risk Control보다 우선하지 않는다.

---

29. Execution Priority

절대적인 우선순위:

Risk
 ↓
Safety
 ↓
Correctness
 ↓
Execution Quality
 ↓
Speed

속도를 위해 안전성을 희생하지 않는다.

---

30. Position Sizing

단기/초단기에서는 Position Size가 더 동적으로 변할 수 있다.

가능한 입력:

Confidence
Volatility
Liquidity
Risk Budget
Signal Strength
Correlation

단, 최종 Size는 Risk Engine의 승인을 받아야 한다.

---

31. Holding Period

Position에:

expectedHoldingPeriod

개념을 도입할 수 있다.

예:

Long
Short
Intraday

---

32. Intraday Position Rule

초단기 시스템에서는:

Market Close

를 기준으로 Position을 강제 청산할지 여부를 명시적으로 Policy화한다.

자동으로 가정하지 않는다.

---

33. Short-Term Risk

추가 Risk:

Gap Risk
Liquidity Risk
Spread Risk
Slippage Risk
Volatility Spike
Event Risk
Execution Risk

---

34. Circuit Breaker

초단기 시스템에서는 시스템 수준의 Circuit Breaker가 필요할 수 있다.

예:

Volatility Spike
Data Failure
Broker Failure
Execution Failure
Loss Limit

발생 시:

Trading Halt

---

35. Intraday Loss Limit

하루 단위 Risk Limit을 별도로 관리할 수 있다.

Daily Loss Limit

초과 시:

NO NEW POSITION

---

36. Frequency Risk

초단기 시스템에서는 과도한 거래가 발생할 수 있다.

관리 대상:

Orders / Day
Trades / Day
Turnover
Signal Frequency
Cancel Frequency

---

37. Overtrading Control

다음 상황에서는 주문을 제한할 수 있다.

Signal Churn
High Turnover
Repeated Entry/Exit
Low Expected Edge
High Cost

---

38. Edge vs Cost

단기 전략의 핵심 검증:

Expected Edge > Expected Cost

이어야 한다.

Cost보다 작은 Edge는 전략으로 채택하지 않는다.

---

39. Backtest Principle

단기 Backtest에서는 특히:

Lookahead Bias
Survivorship Bias
Data Snooping
Overfitting
Transaction Cost
Slippage
Latency

를 관리한다.

---

40. Walk-Forward

단기 전략 검증에서는:

Train
 ↓
Validate
 ↓
Test
 ↓
Forward

구조를 사용한다.

---

41. Out-of-Sample

최종 전략 평가는 OOS 결과를 중심으로 한다.

In-Sample 성과만으로 Production 진입을 결정하지 않는다.

---

42. Parameter Stability

Parameter가 조금만 바뀌어도 성과가 붕괴하는 전략은 위험하다.

따라서:

Parameter
→ Sensitivity
→ Stability

를 검증한다.

---

43. Strategy Registry

Book 4에서는 Strategy Registry를 도입한다.

Strategy ID
Version
Horizon
Universe
Feature Set
Policy
Risk Profile
Execution Profile

---

44. Strategy Isolation

전략 간 상태를 함부로 공유하지 않는다.

Strategy A
Strategy B
Strategy C

가 서로의 Position이나 State를 직접 변경하지 않는다.

Portfolio Layer에서 통합한다.

---

45. Portfolio Integration

최종 구조:

Long Strategy
Short Strategy
Ultra-Short Strategy
       ↓
Portfolio Engine
       ↓
Risk
       ↓
Execution

---

46. Capital Allocation

전략별 Risk Budget을 분리할 수 있다.

예:

Long
Short
Ultra-Short

각각 별도의 Risk Budget을 가진다.

구체적인 비율은 실험 결과에 따라 결정한다.

---

47. Correlation

서로 다른 전략이 사실상 같은 Position을 만드는 경우를 관리한다.

Strategy Correlation
Factor Exposure
Sector Exposure
Position Overlap

을 고려한다.

---

48. Conflict Resolution

전략 간 충돌:

Long BUY
Short SELL

은 오류가 아니다.

Portfolio Policy가:

Net Position
Gross Exposure
Risk Budget

을 기준으로 최종 결정을 내린다.

---

49. Real-Time Architecture

초단기 시스템은 기존 Batch Pipeline과 별도로 Real-Time Pipeline이 필요할 수 있다.

Market Event
 ↓
Stream
 ↓
Feature Update
 ↓
Signal
 ↓
Risk
 ↓
Execution

---

50. Batch vs Stream

Batch
=
정기 계산

Stream
=
Event 기반 계산

두 Pipeline을 무조건 하나로 통합하지 않는다.

---

51. State Management

Real-Time 시스템에서는 State가 중요하다.

최소:

Market State
Feature State
Signal State
Position State
Order State
Risk State

를 관리한다.

---

52. Event Ordering

Event가 순서대로 도착한다는 보장을 하지 않는다.

따라서:

Event Time
Sequence
Version

을 사용하여 순서를 검증한다.

---

53. Duplicate Event

동일 Event가 다시 들어와도 시스템 상태가 중복 변경되지 않아야 한다.

Event ID

기반 Idempotency를 사용한다.

---

54. Late Event

늦게 도착한 Event는:

Late Event

로 식별한다.

이미 처리한 Decision을 임의로 과거로 수정하지 않는다.

---

55. Real-Time Failure

초단기 시스템에서는 다음 상황을 특별히 처리한다.

Feed Disconnect
Latency Spike
Data Gap
Sequence Gap
Duplicate Event
Out-of-Order Event
Broker Disconnect

---

56. Fail-Safe

실시간 시스템은:

Data Uncertain
→ Trading Conservative

원칙을 사용한다.

---

57. Latency

Latency를 측정한다.

Market Event
→ Receive
→ Process
→ Decision
→ Submit
→ Ack

각 구간을 기록한다.

---

58. Latency Budget

전체 Latency를 하나의 숫자로만 관리하지 않는다.

구간별:

Feed Latency
Processing Latency
Decision Latency
Network Latency
Broker Latency

를 관리한다.

---

59. Monitoring

Book 4 Monitoring은 Book 3 Monitoring을 확장한다.

추가:

Feed Health
Latency
Spread
Liquidity
Signal Frequency
Order Frequency
Slippage
Fill Rate

---

60. Book 4의 핵심 목표

Book 4의 목표는:

더 빠른 매매

가 아니다.

정확한 목표:

기존 투자 시스템을
더 짧은 시간축에서도
PIT-safe
Risk-safe
Execution-safe
하게 동작시키는 것

이다.

---

61. 구현 우선순위

Book 4 구현은 다음 순서를 따른다.

P0
Time Horizon Model
Data Frequency
Intraday Contract
Timestamp / PIT

P1
Short-Term Features
Regime
Event
Volatility
Liquidity

P2
Short Signal
Ultra-Short Signal
Multi-Horizon

P3
Position Sizing
Intraday Risk
Cost Model
Slippage

P4
Real-Time Pipeline
Execution Optimization
Latency

P5
Paper
Replay
Walk Forward
OOS
Production

---

62. Book 4가 변경하면 안 되는 것

Book 3의 다음 원칙은 그대로 유지한다.

PIT
Versioning
Audit
Risk Gate
Execution Boundary
Idempotency
Reconciliation
Kill Switch
Monitoring
Recovery

---

63. Book 4에서 새로 추가할 것

Time Horizon
Intraday Data
Event Time
Market Microstructure
Short-Term Feature
Intraday Risk
Transaction Cost
Slippage
Latency
Real-Time Pipeline
Multi-Horizon Portfolio

---

64. Book 4와 Book 3의 경계

Book 3:

How to build a safe investment system

Book 4:

How to extend that system to shorter time horizons

Book 4는 Book 3의 대체판이 아니다.

---

65. Chapter 구성 원칙

Book 4의 Chapter 수는 처음부터 고정하지 않는다.

먼저:

Architecture
Data
Features
Signal
Risk
Execution
Backtest
Real-Time
Portfolio
Production

의 설계를 확정한 후 Chapter를 분할한다.

Book 3에서 발생했던 "Chapter가 지나치게 길어지는 문제"를 반복하지 않는다.

---

66. Chapter 작성 규칙

각 Chapter는 다음 형식을 기본으로 한다.

1. Objective
2. Scope
3. Inputs
4. Outputs
5. Data Contract
6. Processing Rules
7. Failure Rules
8. Test Requirements
9. Implementation Boundary
10. Dependencies

사용자에게 설명하는 장황한 서술은 최소화한다.

---

67. Coding Agent 기준

Claude Code / Codex가 Book 4를 구현할 때:

BOOK4_MASTER.md
        ↓
관련 Chapter
        ↓
Book 3 기존 구현
        ↓
현재 Repository
        ↓
Minimal Change
        ↓
Test

순서로 작업한다.

---

68. 기존 시스템 재사용 원칙

Book 4에서 이미 구현된 Book 3 Component를 재작성하지 않는다.

예:

Risk Engine
Version System
Diagnostics
Audit
Execution Guard

가 충분하면 그대로 재사용한다.

---

69. 새로운 Module을 만드는 조건

새 Module은 다음 중 하나가 필요할 때만 만든다.

새로운 책임
새로운 시간축
새로운 데이터 구조
새로운 실행 요구
새로운 Risk Control

단순히 기존 Module의 이름이 마음에 들지 않는다는 이유로 재작성하지 않는다.

---

70. Research First

Book 4의 새로운 Feature/Strategy는 먼저 Research 영역에서 검증한다.

Idea
 ↓
Research
 ↓
Replay
 ↓
OOS
 ↓
Paper
 ↓
Shadow
 ↓
Production

---

71. No Strategy Without Evidence

단기/초단기 전략은 특히 과최적화 가능성이 높다.

따라서:

Backtest Profit

만으로 전략을 채택하지 않는다.

최소:

OOS
Cost Adjusted
Stability
Drawdown
Turnover
Execution Feasibility

를 확인한다.

---

72. Final Book 4 Architecture

                 MARKET DATA
                      │
          ┌───────────┼───────────┐
          ↓           ↓           ↓
        LONG        SHORT      ULTRA-SHORT
          │           │           │
          ↓           ↓           ↓
       Feature     Feature      Feature
          │           │           │
          ↓           ↓           ↓
        Score       Score        Score
          │           │           │
          ↓           ↓           ↓
       Signal      Signal       Signal
          └───────────┼───────────┘
                      ↓
              Portfolio Engine
                      ↓
                 Risk Engine
                      ↓
                Order Intent
                      ↓
             Execution Engine
                      ↓
                   Broker
                      ↓
              Reconciliation

---

73. Final Design Principle

Book 4에서 가장 중요한 것은:

시간축이 짧아질수록
속도보다
데이터 정확성,
시간 정합성,
비용,
유동성,
Risk,
Execution
의 중요성이 커진다.

---

74. Book 4 Completion Definition

Book 4는 다음을 만족할 때 완료한다.

[ ] Multi-Horizon Model
[ ] Intraday Data Contract
[ ] Timestamp Model
[ ] Intraday PIT
[ ] Short Feature Layer
[ ] Ultra-Short Feature Layer
[ ] Regime
[ ] Event
[ ] Liquidity
[ ] Volatility
[ ] Cost Model
[ ] Slippage Model
[ ] Multi-Horizon Signal
[ ] Portfolio Integration
[ ] Intraday Risk
[ ] Real-Time Pipeline
[ ] Latency Monitoring
[ ] Replay
[ ] Walk Forward
[ ] OOS
[ ] Paper
[ ] Shadow
[ ] Production

---

75. Final Rule

Book 4는 기존 시스템을 버리고 새로운 트레이딩 시스템을 만드는 프로젝트가 아니다.

Book 3 Core
+
Short-Term Layer
+
Ultra-Short Layer

를 구축하는 확장 프로젝트다.

기존의:

PIT
Risk
Execution Safety
Versioning
Audit
Recovery

를 희생하면서 단기/초단기 성능을 높이는 설계는 채택하지 않는다.

Book 4 Master Baseline — DRAFT / 설계 확정 전