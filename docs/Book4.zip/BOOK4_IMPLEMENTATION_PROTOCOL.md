BOOK4_IMPLEMENTATION_WORKFLOW.md

Book 4 Implementation Workflow

0. 문서 목적

이 문서는 Book 4 Chapter를 실제 Book 3 Repository에 구현할 때 사용하는 공통 실행 규칙이다.

이 문서는 Book 4의 Architecture나 Chapter 내용을 새로 정의하지 않는다.

역할은 다음과 같다.

Book 3 Repository
        +
BOOK4_MASTER
        +
BOOK4_ARCHITECTURE_v2
        +
해당 Book 4 Chapter
        ↓
BOOK4_IMPLEMENTATION_WORKFLOW
        ↓
분석 → 구현 → 테스트 → 검증 → 결과 보고

목표는 단 하나다.

«Book 3의 기존 구조를 최대한 재사용하면서 Book 4의 요구사항을 최소 변경으로 구현하고, 구현 직후 테스트와 정합성 검증까지 완료한다.»

---

1. 최우선 원칙

1.1 Book 3이 기존 시스템의 기준선이다

Book 4 구현을 시작하기 전에 반드시 현재 Repository의 실제 구현을 확인한다.

설계 문서에 존재한다는 이유만으로 새로운 Module, Engine, Contract를 생성하지 않는다.

우선순위:

실제 Repository
    ↓
실제 Contract
    ↓
실제 Engine / Module
    ↓
기존 Test
    ↓
Book 4 Architecture
    ↓
Book 4 Chapter

설계 문서와 실제 Repository가 다르면 실제 Repository를 확인하고 차이를 결과 보고에 기록한다.

---

2. 구현 전 필수 분석

각 Chapter 구현을 시작할 때 다음 순서를 반드시 수행한다.

STEP 1. Chapter 요구사항 추출
STEP 2. 관련 Book 3 Module 검색
STEP 3. 관련 Contract 검색
STEP 4. 관련 Test 검색
STEP 5. 기존 Extension Point 확인
STEP 6. REUSE / EXTEND / NEW 판정
STEP 7. 구현 범위 결정

구현 전에 Repository를 충분히 탐색하지 않고 코드를 작성하지 않는다.

---

3. REUSE / EXTEND / NEW 규칙

3.1 REUSE

기존 Book 3 구현으로 Book 4 요구사항을 충족할 수 있으면 변경하지 않는다.

Book 3 Component
      ↓
Book 4에서 그대로 사용

불필요한 abstraction, wrapper, duplicate module을 만들지 않는다.

---

3.2 EXTEND

기존 구조로 대부분 충족하지만 Book 4 요구사항 때문에 최소 변경이 필요한 경우 EXTEND로 판정한다.

원칙:

Existing Component
        ↓
Minimal Extension

기존 책임과 Interface를 가능한 한 유지한다.

변경 시:

- 기존 동작 유지
- backward compatibility 유지
- versioning 필요 여부 확인
- 기존 test 유지
- 신규 test 추가

를 수행한다.

---

3.3 NEW

NEW는 가장 엄격하게 사용한다.

다음 조건을 모두 만족하는 경우에만 신규 Module/Component를 생성할 수 있다.

1. Book 3에 동일 책임의 Component가 없음
2. 기존 Component 확장으로 해결할 수 없음
3. Book 4 Architecture가 신규 Component를 허용함
4. 신규 책임이 명확하게 정의됨
5. 기존 Engine과 책임이 중복되지 않음

위 조건 중 하나라도 충족하지 못하면 NEW 구현을 중단하고 기존 구조를 다시 확인한다.

---

4. 기존 Engine 재작성 금지

Book 4 구현에서 다음 Engine을 기존 기능과 별도로 복제하지 않는다.

Score Engine
Risk Engine
Portfolio Engine
Action Engine
Execution Engine
PIT Engine
Replay Engine
State Engine
Event Engine

Book 3에 동일 책임의 Engine이 존재하면 반드시 먼저 재사용 가능성을 검토한다.

예:

잘못된 방식

Book 3 Risk Engine
        +
Book 4 Intraday Risk Engine


권장 방식

Book 3 Risk Engine
        ↓
Book 4 Risk Policy Extension

---

5. Contract 변경 규칙

5.1 최소 변경 원칙

Book 4 요구사항을 만족하기 위해 Contract 변경이 필요한 경우에만 변경한다.

필드 추가를 목적으로 Contract를 변경하지 않는다.

---

5.2 BaseContract 보호

"horizon"을 BaseContract에 무조건 추가하지 않는다.

다음과 같이 공통 Base Contract를 오염시키지 않는다.

BaseContract
    └── horizon   ← 자동 추가 금지

실제 Book 3 Contract를 확인한 뒤 Horizon 정보가 필요한 객체에만 최소 범위로 추가한다.

가능한 위치의 예:

Strategy
Signal
Policy
Decision

단, 실제 Repository 구조를 확인한 후 결정한다.

---

5.3 Backward Compatibility

기존 Book 3 입력과 출력이 Book 4 변경 때문에 불필요하게 깨지면 안 된다.

Contract 변경이 필요한 경우:

Existing Contract
      ↓
Backward-compatible Extension
      ↓
Validation
      ↓
Regression Test

breaking change가 필요하다고 판단되면 자동으로 구현하지 않고 BLOCKED 상태로 보고한다.

---

6. PIT 규칙

Book 3의 PIT 의미를 유지한다.

핵심 조건:

availableAt <= decisionTime

Book 4는 새로운 PIT Engine을 만들지 않는다.

Intraday/Event-Time 정보는 기존 PIT 구조에 연결한다.

---

6.1 PIT와 Operational Timestamp 분리

다음 개념을 혼합하지 않는다.

PIT

eventTime
availableAt
decisionTime

Operational / Latency

receivedAt
processedAt
submittedAt
executedAt

Operational timestamp를 추가한다고 해서 PIT semantics를 변경하지 않는다.

---

7. Horizon 규칙

Book 4의 Horizon은 새로운 독립 Engine으로 구현하지 않는다.

Horizon은 필요한 위치에서 metadata / policy / decision context로 사용한다.

예:

LONG
SHORT
ULTRA_SHORT

단, 실제 Book 3 구조를 먼저 확인한다.

모든 Contract에 "horizon"을 일괄 추가하지 않는다.

---

8. Short / Ultra-Short 규칙

Book 3에 이미 Short-Term / Ultra-Short-Term 관련 구조가 존재하면 이를 재사용한다.

Book 4에서:

Short Signal Engine
Ultra-Short Signal Engine

을 별도로 복제하지 않는다.

Book 4는 기존 Signal Layer에 다음과 같은 추가 정보를 공급하는 방향을 우선한다.

Intraday Feature
Microstructure
Event-Time Context
Market State
Liquidity
Volatility

---

9. Microstructure 규칙

Microstructure는 신규 정보 영역으로 취급한다.

예:

Bid
Ask
Spread
Depth
Trade
Order Flow
Imbalance

그러나 Microstructure를 이유로 별도의 전략 시스템을 생성하지 않는다.

권장 구조:

Microstructure Data
        ↓
Existing Feature Architecture
        ↓
Existing Signal
        ↓
Existing Risk
        ↓
Existing Execution

Microstructure 자체가 새로운 Trading Engine이 되어서는 안 된다.

---

10. Risk 규칙

Book 3 Risk Engine을 재사용한다.

Book 4에서 필요한 Intraday Risk는 기존 Risk Policy / Risk Gate 구조에 추가 가능한지 먼저 확인한다.

예:

Existing Risk Engine
        ↓
Existing Risk Policy
        +
Intraday Policy Extension

새로운 Risk Engine을 만드는 것은 마지막 수단이며, 위의 NEW 조건을 모두 만족해야 한다.

---

11. Portfolio / Action 규칙

Book 3의 Portfolio / Action 구조를 우선 재사용한다.

Horizon 간 충돌이 발생하더라도 새로운 Portfolio Engine을 먼저 만들지 않는다.

예:

Long   BUY
Short  SELL
Ultra  HOLD

이러한 신호를 기존 Portfolio / Action 구조에서 처리할 수 있는지 먼저 확인한다.

필요한 경우:

Existing Portfolio / Action
        ↓
Multi-Horizon Coordination Policy

형태로 확장한다.

---

12. Execution 규칙

Book 3의 다음 안전 경계를 유지한다.

Order Intent
Execution Adapter
Idempotency
Reconciliation
Execution Safety

Book 4에서 Execution Quality가 필요하더라도 기존 Execution Engine을 복제하지 않는다.

Execution Quality는 가능한 경우 별도의 measurement 영역으로 분리한다.

예:

Execution
    ↓
Execution Measurement
    ├── Fill
    ├── Cost
    ├── Slippage
    ├── Market Impact
    └── Latency

기존 안전성 계층을 우회하지 않는다.

---

13. Cost / Slippage 규칙

Cost와 Slippage를 기존 Execution Contract에 무조건 필드로 삽입하지 않는다.

먼저 현재 Repository의 Cost / Slippage 구현을 확인한다.

가능하면 기존 모델을 재사용하고 필요한 측정값만 확장한다.

검증 시 최소한 다음을 확인한다.

Fee
Tax
Spread
Slippage
Market Impact

필요한 항목만 채택한다.

---

14. Event / State 규칙

Book 3에 Event / State 구조가 존재하면 이를 재사용한다.

Book 4에서는 필요한 경우 다음을 확장한다.

Sequence
Ordering
Duplicate Event
Late Event
Out-of-order Event
Event Timestamp

그러나 새로운 Event Engine이나 State Engine을 먼저 만들지 않는다.

---

15. Real-Time / Streaming 규칙

Real-Time은 기본적으로 CONDITIONAL이다.

Intraday 요구사항이 있다고 해서 Streaming Runtime을 자동으로 생성하지 않는다.

우선:

Batch
 ↓
Replay
 ↓
Intraday Validation
 ↓
Latency Requirement 확인

을 수행한다.

Batch/Replay로 요구사항을 충족할 수 있으면 Streaming Runtime을 추가하지 않는다.

실제 latency requirement가 충족되지 않는 경우에만:

Streaming Adapter

도입을 검토한다.

---

16. Test-First 구현 규칙

구현 완료를 코드 작성 완료로 판단하지 않는다.

다음 순서를 따른다.

Code Change
    ↓
Unit Test
    ↓
Integration Test
    ↓
Regression Test
    ↓
Book 3 Compatibility Test
    ↓
Chapter Acceptance Test

하나라도 실패하면 PASS로 보고하지 않는다.

---

17. 기존 Test 보호

Book 3 기존 테스트를 삭제하거나 약화하지 않는다.

특히:

PIT
Contract
Risk
Execution
Idempotency
Reconciliation
Replay
Versioning

관련 기존 테스트를 보호한다.

테스트를 수정해야 하는 경우 반드시 변경 이유를 결과에 기록한다.

---

18. Regression Test

Book 4 변경 후 기존 Book 3 동작이 유지되는지 확인한다.

최소 검증:

Existing Input
      ↓
Existing Processing
      ↓
Existing Output

이 Book 4 변경 때문에 달라지지 않는지 확인한다.

변경이 의도된 경우:

Before
After
Reason
Compatibility Impact

를 기록한다.

---

19. 구현 중 발견되는 Architecture 충돌

Chapter와 실제 Repository가 충돌하는 경우 임의로 Architecture를 변경하지 않는다.

다음 순서를 따른다.

Chapter 요구사항
      ↓
Book 4 Architecture 확인
      ↓
Book 3 실제 구현 확인
      ↓
충돌 확인

충돌이 단순 구현상의 문제이고 최소 변경으로 해결 가능하면 구현한다.

Architecture 변경이 필요한 경우:

BLOCKED

로 보고하고 자동으로 구조를 변경하지 않는다.

---

20. Forbidden Changes

다음 작업은 특별한 근거 없이 수행하지 않는다.

- Book 3 Engine 복제
- 기존 Engine 이름만 바꾼 신규 Engine 생성
- BaseContract에 horizon 일괄 추가
- 모든 Contract에 timestamp 일괄 추가
- 기존 PIT semantics 변경
- 기존 Risk Gate 우회
- Execution Safety 우회
- Idempotency 제거
- Reconciliation 우회
- 기존 Test 삭제
- 기존 Test를 통과시키기 위한 검증 약화
- Tick 저장을 이유만으로 Production Pipeline 구축
- Streaming Runtime 선구축
- 기존 Contract breaking change
- Chapter에 없는 기능 임의 추가

---

21. 구현 완료 조건

Chapter 구현은 다음 조건을 모두 만족해야 완료로 판정한다.

[ ] Chapter 요구사항 확인
[ ] Book 3 기존 구현 확인
[ ] 관련 Contract 확인
[ ] REUSE / EXTEND / NEW 판정
[ ] 구현 완료
[ ] Unit Test PASS
[ ] Integration Test PASS
[ ] Regression Test PASS
[ ] Book 3 Compatibility PASS
[ ] Chapter Acceptance Test PASS
[ ] PIT 검증 PASS
[ ] Contract Validation PASS
[ ] 변경 파일 확인
[ ] 불필요한 신규 Module 확인
[ ] Architecture Deviation 확인

---

22. 작업 결과 보고 형식

각 Chapter 작업이 끝나면 반드시 다음 형식으로 결과를 보고한다.

CHAPTER IMPLEMENTATION RESULT

Chapter:
<chapter number / name>

Status:
PASS / PARTIAL / BLOCKED

1. Requirement
- ...

2. Existing Book 3 Components Reused
- ...

3. Extensions
- ...

4. New Components
- ...

5. Changed Contracts
- ...

6. Changed Files
- ...

7. Tests
- Unit: PASS / FAIL
- Integration: PASS / FAIL
- Regression: PASS / FAIL
- Book3 Compatibility: PASS / FAIL
- Chapter Acceptance: PASS / FAIL

8. Architecture Deviation
- NONE
또는
- ...

9. Unresolved Issues
- NONE
또는
- ...

10. Final Decision
PASS / PARTIAL / BLOCKED

---

23. BLOCKED 조건

다음 상황에서는 임의로 우회하지 않고 BLOCKED로 보고한다.

- Book 3 실제 구조와 Chapter가 충돌
- Breaking Contract Change 필요
- 기존 Engine과 신규 Engine의 책임 경계가 불명확
- Architecture 변경이 필요
- 기존 PIT semantics 변경이 필요
- 기존 Risk / Execution Safety를 우회해야 함
- 기존 테스트와 요구사항이 충돌
- 필요한 Repository 구현을 찾을 수 없음
- 요구사항을 구현할 수 있는 근거가 부족함

---

24. 최종 실행 프로토콜

Claude Code / Codex는 각 Chapter에 대해 다음 프로토콜을 사용한다.

START
  ↓
Read Chapter
  ↓
Read relevant Architecture rules
  ↓
Search Book 3 Repository
  ↓
Inspect Contract
  ↓
Inspect Engine
  ↓
Inspect Tests
  ↓
Determine REUSE / EXTEND / NEW
  ↓
Implement minimum required change
  ↓
Run Unit Tests
  ↓
Run Integration Tests
  ↓
Run Regression Tests
  ↓
Run Book 3 Compatibility Tests
  ↓
Run Chapter Acceptance Tests
  ↓
Check PIT / Contract / Versioning
  ↓
Check forbidden changes
  ↓
Generate Implementation Result
  ↓
PASS / PARTIAL / BLOCKED
END

---

25. 핵심 원칙 요약

Book 4 구현에서 가장 중요한 규칙은 다음 한 문장으로 요약한다.

«Book 4는 Book 3을 다시 만드는 프로젝트가 아니라, Book 3의 기존 Contract와 Engine을 검증한 후 필요한 최소 Extension만 추가하는 프로젝트다.»

따라서 구현자는 항상:

SEARCH FIRST
REUSE FIRST
EXTEND MINIMALLY
TEST IMMEDIATELY
DO NOT DUPLICATE
DO NOT BREAK PIT
DO NOT BREAK SAFETY
DO NOT GUESS

를 따른다.

이 문서는 모든 Book 4 Chapter 구현에 공통 적용한다.