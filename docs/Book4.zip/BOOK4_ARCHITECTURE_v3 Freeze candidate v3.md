BOOK4_ARCHITECTURE_v3.md

Book 4 Architecture

Architecture Freeze Candidate v3

Status: FREEZE CANDIDATE
Scope: Book 4 — Intraday / Microstructure / Execution Extension
Baseline: Book 3 Complete
Previous Architecture: BOOK4_ARCHITECTURE_v2
Audit Basis: Book 3 Architecture Audit + Module Audit + Contract-Level Audit
Implementation Verification: Partial — actual "contracts/*.py" source field verification remains pending

---

0. 문서 목적

이 문서는 Book 4의 시스템 Architecture를 확정하기 위한 기준선이다.

Book 4는 새로운 투자 시스템을 구축하지 않는다.

Book 3에서 이미 구축된:

Data
PIT
Feature
Market State
Event
State
Score
Confidence
Short Signal
Ultra-Short Signal
Action
Portfolio
Risk
Execution
Replay
Validation
Monitoring
Recovery
Audit

을 그대로 Core로 사용하고,

Book 4에서는 다음 영역을 필요한 범위에서 확장한다.

Intraday Data
Timestamp Resolution
Event Ordering
Intraday Feature
Microstructure
Cost / Slippage
Execution Quality
Latency
Horizon Coordination
Conditional Streaming

핵심 원칙:

«Book 4 = New System이 아니라 Book 3 Extension Layer»

---

1. Architecture Status

현재 Architecture는 최종 Freeze가 아니다.

현재 상태:

Book 3 Architecture Audit
        ↓
Book 3 Module Audit
        ↓
Book 3 Contract 의미/문서 Audit
        ↓
Book 4 Requirements Mapping
        ↓
BOOK4_ARCHITECTURE_v3
        ↓
Architecture Review
        ↓
FINAL FREEZE

실제 Repository의 모든 "contracts/*.py" 파일이 확보되지 않았으므로 다음을 구분한다.

DOCUMENT-CONFIRMED
    Book 3 문서에서 확인됨

IMPLEMENTATION-UNVERIFIED
    실제 Python Contract 필드까지 직접 확인되지 않음

ARCHITECTURE DECISION
    Book 4에서 반드시 유지해야 하는 설계 원칙

EXTENSION CANDIDATE
    실제 구현 확인 후 필요한 경우에만 변경

CONDITIONAL
    필요성이 검증될 경우에만 구현

확인되지 않은 구현 필드는 임의로 추가하지 않는다.

---

2. Book 3를 Core로 고정

Book 4는 Book 3의 Engine을 복제하거나 재작성하지 않는다.

2.1 재사용 대상

BaseContract
Data Contract
PIT
Feature Architecture
Market State
Event Architecture
State Architecture
Score Engine
Confidence
Short Signal
Ultra-Short Signal
Action
Portfolio
Risk
Execution
Replay
Validation
Monitoring
Recovery
Audit
Kill Switch
Versioning
Diagnostics

이 영역은 Book 4의 기반으로 사용한다.

---

3. Core / Extension Boundary

전체 Architecture:

                    BOOK 3 CORE
────────────────────────────────────────────

Data
PIT
Feature
Market State
Event
State
Score
Confidence
Short Signal
Ultra-Short Signal
Action
Portfolio
Risk
Execution
Replay
Validation
Monitoring
Recovery
Audit
Kill Switch
Versioning
Diagnostics

────────────────────────────────────────────
              Extension Boundary
────────────────────────────────────────────

                    BOOK 4
────────────────────────────────────────────

Intraday Data Adapter
Timestamp Resolution
Event Ordering
Intraday Feature
Microstructure
Cost / Slippage Extension
Execution Quality
Latency Measurement
Horizon Coordination
Conditional Streaming

────────────────────────────────────────────

Book 4 Extension은 기존 Core의 책임을 대체하지 않는다.

---

4. BaseContract

Book 3에서 확인된 BaseContract 공통 메타데이터:

version
generated_at
source
trace_id

Book 4에서 다음 필드를 BaseContract에 추가하지 않는다.

horizon
frequency
eventTime
availableAt
decisionTime
receivedAt
processedAt
executionTime

이유:

모든 Contract가 Horizon이나 Intraday 시간 정보를 본질적으로 필요로 하는 것은 아니기 때문이다.

Decision

BaseContract = REUSE

Book 4의 공통 BaseContract 변경은 금지한다.

---

5. Horizon Model

Book 3에는 이미 Short-Term / Ultra-Short-Term Signal 영역이 존재한다.

따라서 Book 4는 새로운 Short Engine이나 Ultra-Short Engine을 만들지 않는다.

Horizon은 Engine이 아니라:

Policy / Metadata

개념으로 취급한다.

기본 개념:

LONG
SHORT
ULTRA_SHORT

단, Book 4에서 구체적인 holding period / decision frequency / data frequency 값을 이 문서에서 임의로 고정하지 않는다.

Horizon의 위치

현재 후보:

Strategy
Signal
Policy
Decision

중 필요한 위치에만 적용한다.

"BaseContract.horizon"은 사용하지 않는다.

Status

Horizon
= MINIMAL EXTENSION CANDIDATE

실제 "strategy.py" / Signal Contract 확인 후 최종 필드 위치를 확정한다.

---

6. Data Architecture

Book 3의 Data Contract와 PIT 원칙을 재사용한다.

Book 4에서는 데이터 시간 해상도를 확장할 수 있다.

Daily
Hourly
15m
5m
1m
Tick

그러나 모든 Horizon이 모든 frequency를 사용하는 것은 아니다.

따라서:

Required Horizon
      ↓
Decision Frequency
      ↓
Required Data Frequency
      ↓
Storage Requirement

순서로 결정한다.

---

7. Intraday Data Adapter

Book 4에서 새롭게 필요한 핵심 영역 중 하나다.

구조:

Market Data Source
        ↓
Intraday Adapter
        ↓
Book 3 Data Contract
        ↓
PIT Validation
        ↓
Feature Layer

Intraday Adapter는 새로운 Data Engine이 아니다.

역할:

source-specific data
        ↓
Book 3 compatible data contract

로 변환하는 Adapter다.

Status

Intraday Data Adapter = NEW ADAPTER / EXTENSION

단, 기존 Data Adapter가 동일 기능을 제공하는 경우 재사용한다.

---

8. PIT Architecture

Book 3에서 이미 다음 개념이 존재한다.

eventTime
availableAt
decisionTime

핵심 규칙:

availableAt <= decisionTime

이 규칙은 Book 4에서도 변경하지 않는다.

Book 4의 역할

Book 4는 새로운 PIT Engine을 만들지 않는다.

Book 3 PIT
     ↓
Intraday Timestamp Resolution
     ↓
Existing PIT Validation

으로 확장한다.

Decision

PIT = REUSE

PIT semantics 변경 금지.

---

9. Timestamp Architecture

Timestamp는 두 종류로 분리한다.

9.1 PIT Timestamp

eventTime
availableAt
decisionTime

PIT의 정보 가용성을 판단하는 시간이다.

9.2 Operational Timestamp

필요한 경우:

receivedAt
processedAt
submittedAt
acknowledgedAt
executedAt

등을 사용할 수 있다.

Operational timestamp는 PIT Contract와 동일한 개념으로 취급하지 않는다.

원칙

PIT Time
    ≠
Operational Latency Time

Book 4에서 모든 timestamp를 공통 Contract 필수 필드로 만들지 않는다.

Status

Timestamp Resolution = MINIMAL EXTENSION CANDIDATE

실제 Contract 필드 확인 후 최종 결정한다.

---

10. Feature Architecture

Book 3의 Feature Architecture를 그대로 사용한다.

Feature Engine
Feature Store
Feature Calculator
Feature Provider
Feature Cache
Versioning
PIT propagation
Validation

Book 4는 새로운 Feature Engine을 만들지 않는다.

구조:

Book 3 Feature Architecture
            ↓
New Feature Calculators / Namespace
            ↓
Existing Feature Store
            ↓
Existing Signal Layer

---

11. Intraday Feature

Book 4에서는 기존 Feature Architecture에 Intraday Feature를 추가할 수 있다.

예:

Intraday Momentum
Intraday Volatility
Volume Intensity
Price Acceleration
Range Expansion
Liquidity State

단, 위 항목은 Architecture에서 구현 필드로 확정하는 것이 아니다.

Feature는 반드시:

Research
   ↓
Validation
   ↓
Replay
   ↓
Paper
   ↓
Production

순서를 거친다.

---

12. Microstructure

Book 4에서 가장 명확한 신규 정보 영역이다.

후보 정보:

Bid
Ask
Spread
Depth
Trade
Order Flow
Volume Imbalance
Trade Intensity

Microstructure는 별도의 Trading Engine이 아니다.

구조:

Microstructure Data
        ↓
Feature Calculator
        ↓
Existing Feature Contract
        ↓
Existing Feature Store
        ↓
Existing Signal
        ↓
Existing Risk
        ↓
Existing Execution

Decision

Microstructure
= NEW INFORMATION DOMAIN

그러나:

New Microstructure Engine

을 만드는 것은 기본 설계로 채택하지 않는다.

---

13. Market State / Regime

Book 3에 Market State / Regime 구조가 이미 존재한다.

따라서 Book 4에서 Market Regime Engine을 새로 만들지 않는다.

구조:

Existing Market State
        ↓
Higher Timestamp Resolution
        ↓
Intraday Regime Context

필요한 경우 기존 Market State에 새로운 Feature를 공급한다.

Decision

Market Regime = REUSE + EXTEND

---

14. Event Architecture

Book 3의 Event Architecture를 재사용한다.

Book 4에서 추가 검토하는 것은:

sequence
ordering
duplicate
late event
event latency

이다.

구조:

Existing Event
      ↓
Sequence / Ordering Extension
      ↓
Existing State

새로운 Event Engine을 만들지 않는다.

Status

Event = REUSE + EXTEND CANDIDATE

실제 "event.py"의 필드 확인 전에는 구체 필드를 Freeze하지 않는다.

---

15. State Architecture

Book 3의 State Transition / Replay 구조를 재사용한다.

Book 4에서는 다음 상황을 추가로 처리할 수 있어야 한다.

Intraday State
Late Event
Duplicate Event
Out-of-order Event
State Reconciliation

그러나 새로운 State Manager를 만들지 않는다.

구조:

Existing State
      ↓
Intraday State Extension
      ↓
Existing Replay / Recovery

Status

State = REUSE + EXTEND CANDIDATE

---

16. Score Architecture

Book 3 Score Engine을 재사용한다.

Book 4에서:

Long Score
Short Score
Ultra-Short Score

를 하나의 Score로 합치지 않는다.

각 Horizon의 판단은 독립적으로 유지한다.

                 Score Engine
                      │
          ┌───────────┼───────────┐
          ↓           ↓           ↓
       LONG         SHORT     ULTRA-SHORT
       Score         Score        Score

Horizon별 차이는 Criteria / Policy / Feature Set에서 처리하는 것을 우선한다.

Decision

Score = REUSE

Score Contract에 "horizon"을 추가하는 것은 현재 확정하지 않는다.

---

17. Confidence

Book 3 Confidence 구조를 재사용한다.

Book 4에서 Intraday 데이터의:

coverage
freshness
quality

등을 활용할 수 있으나, 새로운 Confidence Engine을 만들지 않는다.

Decision

Confidence = REUSE

필요성이 검증될 경우 Policy 수준에서 확장한다.

---

18. Signal Architecture

Book 3에 Short-Term / Ultra-Short-Term Signal Layer가 이미 존재한다.

따라서 Book 4에서 다음을 만들지 않는다.

New Short Signal Engine
New Ultra-Short Signal Engine

구조:

Existing Feature
      +
Intraday Feature
      +
Microstructure Feature
      +
Event Context
      ↓
Existing Signal Layer

Horizon별 Signal은 독립적으로 유지한다.

---

19. Multi-Horizon Coordination

Book 3에서 Multi-Horizon Agreement / Action 개념이 존재하므로 Book 4에서 새로운 Portfolio Engine을 만드는 것이 아니다.

예:

LONG       BUY
SHORT      SELL
ULTRA      HOLD

처럼 Horizon별 판단이 다를 수 있다.

이를 오류로 처리하지 않는다.

구조:

Long Signal
Short Signal
Ultra-Short Signal
        ↓
Existing Action / Portfolio
        ↓
Coordination Policy
        ↓
Risk

Decision

Multi-Horizon Coordination
= POLICY EXTENSION

---

20. Risk Architecture

Book 3 Risk Engine을 재사용한다.

Book 4에서는 단기/초단기 환경에서 다음 Risk Policy를 추가 검토한다.

Frequency Risk
Overtrading
Spread Risk
Slippage Risk
Volatility Spike
Liquidity Risk
Execution Risk
Daily Loss Limit
Circuit Breaker

하지만:

New Risk Engine

은 만들지 않는다.

구조:

Existing Risk Engine
        ↓
Horizon / Intraday Risk Policy
        ↓
Existing Risk Gate

Decision

Risk = REUSE + POLICY EXTENSION

---

21. Portfolio Architecture

Book 3 Portfolio 구조를 재사용한다.

Book 4의 역할은 Horizon 간 조정 정책을 확장하는 것이다.

Long Exposure
Short Exposure
Ultra-Short Exposure
        ↓
Existing Portfolio
        ↓
Coordination Policy
        ↓
Risk

새로운 Multi-Horizon Portfolio Engine은 만들지 않는다.

Decision

Portfolio = REUSE + COORDINATION POLICY

---

22. Execution Architecture

Book 3의 Execution Boundary를 유지한다.

기존 구조:

Action
   ↓
Risk Gate
   ↓
Order Intent
   ↓
Execution Adapter
   ↓
Execution
   ↓
Reconciliation

Book 4에서도 이 경계를 변경하지 않는다.

---

23. Execution Quality

Book 4의 주요 신규 확장 영역이다.

측정 대상:

Fill Rate
Slippage
Market Impact
Price Improvement
Execution Latency

중요한 경계:

Execution Engine
       ≠
Execution Quality Measurement

구조:

Existing Execution
        ↓
Execution Measurement
        ├── Cost
        ├── Slippage
        ├── Fill
        ├── Impact
        └── Latency

Decision

Execution = REUSE + EXTEND
Execution Quality = EXTENSION

---

24. Cost Model

Book 3에 Transaction Cost / Slippage 개념이 존재하므로 새로운 Cost Engine을 기본 설계로 만들지 않는다.

Book 4에서는 단기 전략의 Net Edge 판단에 비용을 더욱 엄격하게 적용한다.

개념:

Expected Edge
-
Fee
-
Tax
-
Spread
-
Slippage
-
Market Impact
-
Latency Cost
=
Net Edge

단, 각 항목의 실제 Contract 필드는 구현 확인 후 결정한다.

Decision

Cost = REUSE + EXTEND

---

25. Replay / Validation

Book 3의 Replay / Validation Architecture를 재사용한다.

Book 4에서도 신규 전략이나 Feature를 바로 Production에 연결하지 않는다.

검증:

Research
    ↓
Validation
    ↓
Historical Replay
    ↓
Walk-Forward
    ↓
Out-of-Sample
    ↓
Paper / Shadow
    ↓
Production

Intraday 데이터도 동일한 원칙을 따른다.

특히:

PIT
Event Ordering
Transaction Cost
Slippage
Latency

을 Replay에서 검증해야 한다.

Decision

Replay = REUSE + EXTEND
Validation = REUSE + EXTEND

---

26. Audit / Monitoring

Book 3의 Audit / Monitoring을 재사용한다.

Book 4에서는 다음 항목을 추가 측정할 수 있다.

Feed Latency
Processing Latency
Decision Latency
Order Submission Latency
Execution Latency
Fill Quality
Slippage
Event Delay
Late Event
Duplicate Event

그러나 Monitoring System 자체를 새로 만들지 않는다.

Decision

Monitoring = REUSE + EXTEND
Audit = REUSE + EXTEND

---

27. Recovery

Book 3 Recovery 구조를 재사용한다.

Book 4에서는:

Feed interruption
Late event
Duplicate event
Out-of-order event
State mismatch
Execution mismatch

등의 상황을 추가로 검토한다.

구조:

Existing Recovery
        +
Intraday Recovery Cases

Decision

Recovery = REUSE + EXTEND

---

28. Kill Switch

Book 3의 Kill Switch / Emergency Control을 유지한다.

Book 4에서 새로운 Kill Switch 체계를 만들지 않는다.

필요한 경우 기존 정책에 다음 조건을 추가한다.

Daily Loss
Frequency
Execution Failure
Liquidity Collapse
Spread Expansion
Feed Failure
Latency Breach

Decision

Kill Switch = REUSE + POLICY EXTENSION

---

29. Streaming Architecture

Streaming은 Book 4의 필수 Core로 확정하지 않는다.

현재 기본 구조:

Market Data
    ↓
Event
    ↓
State
    ↓
Feature
    ↓
Signal
    ↓
Risk
    ↓
Action
    ↓
Execution

필요성이 확인될 경우:

Market Feed
    ↓
Streaming Adapter
    ↓
Existing Event
    ↓
Existing State
    ↓
Existing Feature
    ↓
Existing Signal
    ↓
Existing Risk
    ↓
Existing Action
    ↓
Existing Execution

으로 연결한다.

Streaming 도입 조건

다음 조건이 충족될 때만 Production Streaming을 검토한다.

Batch / Replay로 충족할 수 없는
실제 latency requirement 존재
+
Intraday Edge 검증
+
Event Ordering 검증
+
Execution Benefit 검증
+
Operational Recovery 검증

Decision

Streaming = CONDITIONAL

---

30. Tick Data

Tick은 기본 Production 데이터로 확정하지 않는다.

검증 순서:

Tick
 ↓
어떤 정보가 추가되는가?
 ↓
어떤 Feature가 만들어지는가?
 ↓
어떤 Signal이 변경되는가?
 ↓
Expected Edge가 있는가?
 ↓
Cost / Slippage 차감 후 Edge가 남는가?
 ↓
Production 가치가 있는가?

이 과정을 통과하지 못하면 Tick 저장/처리를 기본 Architecture로 채택하지 않는다.

---

31. Strategy Registry

Book 4에서 Strategy Registry를 신규 시스템으로 확정하지 않는다.

Book 3의 기존 Strategy / Config / Version 구조로 충분한지 먼저 확인한다.

필요한 경우에만 다음 정보를 추가한다.

Strategy ID
Version
Horizon
Universe
Feature Set
Policy
Risk Profile
Execution Profile

그러나 이 필드 구조는 현재 Architecture Proposal일 뿐 실제 Contract 확정사항이 아니다.

Decision

Strategy Registry = CONDITIONAL

---

32. Contract Decision Matrix

영역| Book 4 판정| 비고
BaseContract| REUSE| 공통 필드 변경 금지
Data Contract| REUSE + EXTEND| frequency/time resolution 검토
PIT| REUSE| "availableAt <= decisionTime" 유지
Timestamp| MINIMAL EXTENSION| PIT와 operational timestamp 분리
Feature Contract| REUSE + EXTEND| Intraday/Microstructure 편입
Market State| REUSE + EXTEND| Intraday resolution
Event| REUSE + EXTEND 후보| ordering/sequence/late event
State| REUSE + EXTEND 후보| intraday/late event
Score| REUSE| Horizon은 Policy 우선
Confidence| REUSE| 필요 시 Policy 확장
Signal| REUSE + EXTEND| 기존 Short/Ultra-Short 활용
Action| REUSE + EXTEND| Horizon coordination
Portfolio| REUSE + POLICY EXTEND| 충돌 조정
Risk| REUSE + POLICY EXTEND| Intraday Risk
Execution| REUSE + EXTEND| Quality measurement
Cost| REUSE + EXTEND| Net Edge
Slippage| REUSE + EXTEND| Execution/Validation
Replay| REUSE + EXTEND| Intraday replay
Validation| REUSE + EXTEND| OOS / Cost 포함
Monitoring| REUSE + EXTEND| latency/fill
Audit| REUSE + EXTEND| event/order trace
Recovery| REUSE + EXTEND| stream/event failure
Kill Switch| REUSE + POLICY EXTEND| intraday conditions
Microstructure| NEW information domain| 기존 Feature Architecture에 편입
Intraday Adapter| NEW adapter/extension| 기존 Contract 연결
Streaming| CONDITIONAL| latency requirement 기반
Strategy Registry| CONDITIONAL| 기존 Strategy 구조 우선

---

33. 절대 금지되는 Book 4 구현

Claude Code / Codex가 Book 4를 구현할 때 다음 작업은 Architecture 위반이다.

❌ 새로운 Score Engine 작성
❌ 새로운 Risk Engine 작성
❌ 새로운 Portfolio Engine 작성
❌ 새로운 Execution Engine 작성
❌ 새로운 PIT Engine 작성
❌ 새로운 Short Strategy Engine 작성
❌ 새로운 Ultra-Short Strategy Engine 작성
❌ 새로운 State Manager 작성
❌ 새로운 Event Engine 작성
❌ BaseContract에 horizon 추가
❌ 모든 Contract에 timestamp 일괄 추가
❌ 모든 Contract에 frequency 일괄 추가
❌ Tick을 Production 기본값으로 확정
❌ Streaming Runtime을 사전 구축

기존 Engine에 필요한 변경이 있는 경우:

Existing Contract
        ↓
Minimal Extension
        ↓
Backward Compatibility
        ↓
Existing Engine

순서를 지킨다.

---

34. Backward Compatibility

Book 3 Contract를 사용하는 기존 코드가 Book 4 Extension 때문에 깨져서는 안 된다.

원칙:

Book 3 Contract
      ↓
Book 4 Extension
      ↓
Existing Consumer
      ↓
기존 동작 유지

새 필드는 가능한 경우 Optional Extension으로 검토한다.

기존 필드 의미를 변경하지 않는다.

기존 필드의 타입을 임의로 변경하지 않는다.

기존 Contract Version의 의미를 변경하지 않는다.

---

35. Contract 변경 승인 조건

Book 4에서 Contract 필드를 변경하기 전에 반드시 다음을 확인한다.

① Book 3 실제 Contract 확인
② 실제 Consumer 확인
③ 실제 Producer 확인
④ Validation 확인
⑤ Serialization 확인
⑥ Versioning 확인
⑦ Existing Test 확인
⑧ Backward Compatibility 확인
⑨ Book 4에서 필드가 정말 필요한지 확인

하나라도 확인되지 않으면 필드 추가를 확정하지 않는다.

---

36. Architecture Boundary 최종 그림

                    BOOK 3
──────────────────────────────────────────

             Existing Core
                    │
       ┌────────────┼────────────┐
       ↓            ↓            ↓
      Data        Feature       State
       │            │            │
       └────────────┼────────────┘
                    ↓
                  Score
                    ↓
                 Signal
                    ↓
                 Action
                    ↓
             Portfolio / Risk
                    ↓
                Execution

                    │
                    │
             Extension Boundary
                    │
                    ↓

                    BOOK 4
──────────────────────────────────────────

Intraday Data Adapter
        │
        ↓
Timestamp Resolution
        │
        ↓
Intraday Feature
        │
        ├──────── Microstructure
        │
        ├──────── Event Context
        │
        └──────── Regime Context
                    │
                    ↓
             Existing Signal
                    │
                    ↓
          Horizon Coordination
                    │
                    ↓
             Existing Risk
                    │
                    ↓
           Existing Execution
                    │
                    ↓
         Execution Quality
                    │
                    ↓
        Latency / Cost / Slippage

Conditional:
Streaming Adapter

---

37. 구현 우선순위

Book 4 구현은 다음 순서를 따른다.

P0 — Contract / Data Boundary

Intraday Data Adapter
Timestamp Resolution
Frequency Policy
PIT Integration

P1 — Information Layer

Intraday Feature
Microstructure
Intraday Regime
Event Ordering
Liquidity
Volatility

P2 — Decision Extension

Existing Short Signal Extension
Existing Ultra-Short Signal Extension
Horizon Coordination

P3 — Risk / Economics

Intraday Risk Policy
Frequency Risk
Overtrading
Cost
Slippage
Execution Feasibility

P4 — Execution / Runtime

Execution Quality
Latency Measurement
Conditional Streaming
State Recovery

P5 — Evidence

Replay
Walk-Forward
OOS
Paper
Shadow
Production

---

38. Architecture Freeze 조건

다음 조건이 모두 확인되면 Architecture를 FINAL FREEZE한다.

□ 실제 Book 3 contracts/*.py 확보
□ BaseContract 실제 구현 확인
□ Data Contract 실제 필드 확인
□ Feature Contract 실제 필드 확인
□ Event Contract 실제 필드 확인
□ State Contract 실제 필드 확인
□ Strategy / Signal 실제 필드 확인
□ Risk Contract 실제 필드 확인
□ Portfolio Contract 실제 필드 확인
□ Execution Contract 실제 필드 확인
□ Validation 확인
□ Serialization 확인
□ Versioning 확인
□ Existing Tests 확인
□ Book 4 변경 필드 확정
□ Backward Compatibility 확인

현재 이 중 실제 Python Contract source 확인 항목은 완료되지 않았다.

따라서 본 문서는:

ARCHITECTURE FREEZE CANDIDATE

이지:

ARCHITECTURE FINAL FREEZE

가 아니다.

---

39. Book 4 Chapter 설계에 대한 제한

Architecture Freeze 이전에는 Chapter 구조를 확정하지 않는다.

Chapter는 다음 단계에서 Architecture가 Freeze된 후 설계한다.

Chapter는 Module 이름을 그대로 나열하는 방식이 아니라:

Architecture Decision
        ↓
Contract
        ↓
Implementation Boundary
        ↓
Validation
        ↓
Implementation Task

를 기준으로 분해한다.

---

40. Claude Code / Codex Implementation Rule

Book 4 구현자는 이 문서를 먼저 읽는다.

그리고 다음 순서를 지킨다.

1. Book 3 기존 구조 탐색
2. 해당 Contract 탐색
3. 해당 Engine 탐색
4. Existing Test 탐색
5. Book 4 요구사항과 비교
6. Existing 구조 재사용 가능 여부 판단
7. 최소 변경 결정
8. 변경 전후 Contract 확인
9. Backward Compatibility 확인
10. Test
11. 구현

다음 행동은 금지한다.

Book 4 요구사항 발견
        ↓
새 Engine 생성

대신:

Book 4 요구사항 발견
        ↓
Book 3 기존 Module 확인
        ↓
재사용 가능?
   ├── YES → 그대로 사용
   │
   └── NO
       ↓
   최소 Extension 검토
       ↓
   Contract 영향 확인
       ↓
   Backward Compatibility 확인
       ↓
   구현

---

41. 최종 Architecture Decision

현재 Book 4 Architecture의 핵심 결정은 다음과 같다.

BOOK 4 IS NOT A NEW TRADING ENGINE.

BOOK 4 IS AN EXTENSION OF BOOK 3.

Book 3의 기존 Core:

Data
PIT
Feature
State
Event
Score
Signal
Risk
Portfolio
Execution
Replay
Monitoring
Recovery
Audit

를 유지한다.

Book 4의 신규/확장 영역:

Intraday Data
Timestamp Resolution
Event Ordering
Intraday Feature
Microstructure
Execution Quality
Latency
Cost / Slippage Extension
Horizon Coordination
Conditional Streaming

을 기존 Core에 연결한다.

가장 중요한 원칙:

«새로운 Engine을 만드는 것보다 기존 Contract와 Engine에 최소 Extension을 추가하는 것을 우선한다.»

그리고:

«실제 Book 3 구현이 확인되지 않은 필드는 Book 4에서 임의로 생성하지 않는다.»

현재 Architecture는 이 원칙을 만족한다.

---

42. 현재 상태

Book 3 Complete
        ↓
Book 3 Architecture Audit       COMPLETE
Book 3 Module Audit             COMPLETE
Book 3 Contract Document Audit   COMPLETE
        ↓
Book 4 Contract-Level Mapping   COMPLETE / PARTIAL
        ↓
BOOK4_ARCHITECTURE_v3           CURRENT
        ↓
Architecture Review             NEXT
        ↓
Actual contracts/*.py Audit     REQUIRED
        ↓
FINAL ARCHITECTURE FREEZE
        ↓
Chapter Design
        ↓
Chapter Implementation Docs

현재 결론:

BOOK4_ARCHITECTURE_v3
= ARCHITECTURE FREEZE CANDIDATE

이며, 실제 "contracts/*.py"가 확보되기 전까지 최종 Freeze하지 않는다.