BOOK4_START.md

Book 4 신규 집필 시작 지침

1. 프로젝트 위치

이 프로젝트는 기존 주식 투자 시스템을 기반으로 한다.

Book 1
→ 투자 판단 원리

Book 2
→ 시스템 아키텍처

Book 3
→ 실제 구현 / 검증 / 운영

Book 4
→ 단기 / 초단기 시스템 확장

---

2. 반드시 먼저 이해할 것

Book 4는 독립적인 새로운 시스템이 아니다.

기존 Book 1~3의 시스템을 유지하면서:

중장기
 ↓
단기
 ↓
초단기

시간축을 확장하는 프로젝트다.

---

3. 가장 먼저 할 일

Book 4 Chapter를 바로 작성하지 않는다.

먼저 다음을 수행한다.

STEP 1

Book 1~3의 구조를 파악한다.

STEP 2

현재 확정된 시스템 Architecture를 확인한다.

STEP 3

Book 3에서 실제 구현된 Module을 확인한다.

STEP 4

단기/초단기 확장에서 필요한 변경사항을 식별한다.

STEP 5

Book 4 Architecture를 먼저 확정한다.

STEP 6

Architecture가 확정된 후 Chapter를 분할한다.

---

4. 중요한 제한

Book 4에서 Book 1~3의 내용을 반복해서 설명하지 않는다.

기존 내용은:

"Book 3에서 정의한 Risk Engine"

처럼 참조한다.

필요한 경우에만 해당 부분을 다시 기술한다.

---

5. 집필 스타일

Book 4는 책이지만 동시에 Implementation Specification이다.

따라서:

긴 설명
↓
최소화

명확한 Contract
↓
우선

Input / Output
↓
명시

Failure Rule
↓
명시

Test
↓
명시

한다.

---

6. Chapter 작성 기준

각 Chapter는:

Objective
Scope
Inputs
Outputs
Contract
Processing
Failure
Test
Implementation Boundary
Dependencies

를 기본으로 한다.

---

7. 절대 변경하지 않는 원칙

PIT
Risk Gate
Execution Boundary
Idempotency
Reconciliation
Versioning
Audit
Monitoring
Recovery
Kill Switch

은 Book 3의 기존 원칙을 유지한다.

---

8. Book 4의 핵심 연구 영역

우선 다음을 설계한다.

Time Horizon
Intraday Data
Timestamp
PIT
Short-Term Feature
Ultra-Short Feature
Market Regime
Event
Liquidity
Volatility
Transaction Cost
Slippage
Multi-Horizon Signal
Portfolio Integration
Intraday Risk
Real-Time Pipeline
Latency

---

9. 가장 중요한 설계 질문

Book 4 설계에서 다음 질문에 먼저 답한다.

1.
단기와 초단기를 정확히 어떻게 정의할 것인가?

2.
기존 Daily Data Pipeline을 어디까지 재사용할 것인가?

3.
Intraday Data를 어떤 주기로 저장할 것인가?

4.
Timestamp와 availableAt을 어떻게 관리할 것인가?

5.
초단기 Feature가 실제 Edge를 추가하는가?

6.
Transaction Cost와 Slippage를 어떻게 모델링할 것인가?

7.
기존 Risk Engine을 어떻게 확장할 것인가?

8.
Multi-Horizon Signal 충돌을 어떻게 처리할 것인가?

9.
Real-Time Pipeline이 필요한 구간은 어디인가?

10.
현재 Broker / Execution 구조가 초단기 실행에 충분한가?

11.
Latency를 어디까지 관리해야 하는가?

12.
Backtest 결과를 어떤 기준으로 Production에 승격할 것인가?

---

10. 집필 중 판단 기준

새로운 아이디어가 나오면 바로 Chapter에 넣지 않는다.

먼저:

Idea
 ↓
Necessity
 ↓
Architecture Impact
 ↓
Data Requirement
 ↓
Risk Impact
 ↓
Execution Impact
 ↓
Testability

를 검토한다.

---

11. 과설계 방지

Book 3에서 발생했던 문제를 반복하지 않는다.

다음과 같은 이유만으로 기능을 추가하지 않는다.

"있으면 좋을 것 같다"
"언젠가 필요할 수 있다"
"다른 시스템에는 있다"

실제 요구사항과 검증 가능한 가치가 있어야 한다.

---

12. 최종 방향

Book 4의 목표:

빠른 매매 시스템

이 아니라:

짧은 시간축에서도
데이터 정합성
+
PIT
+
Risk
+
Execution
+
Cost
를 통제할 수 있는 시스템

이다.

---

13. 첫 작업

첫 번째 응답에서는 Chapter를 작성하지 않는다.

먼저 다음을 제공한다.

1. Book 4 전체 설계 분석

2. Book 3에서 재사용할 Module

3. Book 4에서 변경할 Module

4. 신규 Module

5. Data Architecture

6. Multi-Horizon Architecture

7. Real-Time Architecture 필요 여부

8. Risk / Execution 변경사항

9. 예상 Chapter 구조

10. 구현 우선순위

그 결과를 검토한 후 Book 4 Architecture를 확정한다.

---

14. Final Instruction

Book 4는 설계 → 검토 → 확정 → 집필 → 구현 순서로 진행한다.

Chapter를 먼저 많이 작성하지 않는다.

Architecture가 확정되기 전에 세부 Chapter를 대량 생산하지 않는다.

이 문서를 기준으로 Book 4 설계를 시작한다.