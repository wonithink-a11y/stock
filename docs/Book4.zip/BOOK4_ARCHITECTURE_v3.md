BOOK4_ARCHITECTURE_v3.md

Book 4 Architecture — Architecture Freeze Candidate v3

Status: FREEZE CANDIDATE
Baseline: Book 3 Complete Specification / Master + Chapter 1~20
Previous Baseline: "BOOK4_ARCHITECTURE_v2.md"
Audit Basis: "BOOK4_IMPLEMENTATION_AUDIT_v2.md"
Purpose: Define the minimum architectural extension required to extend the Book 3 investment system into finer-grained intraday, event-time, microstructure, execution-quality, and multi-horizon operating conditions.

---

1. Architecture Decision

Book 4 is not a new trading system.

Book 3 already defines the architecture from Data through Production, including:

Data
→ Feature
→ Universe
→ Market State
→ Event / State
→ Score / Confidence
→ Short-Term Signal
→ Ultra-Short-Term Signal
→ Action
→ Risk
→ Portfolio
→ Execution
→ Replay / Validation
→ Monitoring / Recovery
→ Production

Therefore Book 4 extends the existing system rather than recreating its Engines.

The primary Book 4 problem is:

BOOK 3
Existing Investment System
        ↓
Existing Short / Ultra-Short Capability
        ↓
BOOK 4
Higher Information Resolution
Higher Time Resolution
Higher Execution Resolution

Book 4 therefore focuses on:

Intraday Data
Timestamp Resolution
Event-Time Semantics
Intraday Feature
Microstructure
Intraday Regime Resolution
Cost / Slippage
Execution Quality
Latency
Multi-Horizon Coordination
Conditional Streaming

---

2. Non-Negotiable Architecture Boundary

Book 4 MUST NOT create parallel versions of existing Book 3 Engines.

The following remain authoritative:

Score Engine
Risk Engine
Action Engine
Portfolio Architecture
Execution Engine / Adapter
PIT Foundation
Feature Store
State Architecture
Event Architecture
Replay Engine
Validation Architecture
Monitoring
Recovery
Audit
Kill Switch
Versioning

If Book 4 cannot represent a required concept using an existing Contract or Policy, the implementation MUST use the smallest backward-compatible extension.

The default rule is:

REUSE
    ↓
EXTEND
    ↓
NEW only when existing responsibility cannot represent the requirement

---

3. Classification Model

Every Book 4 requirement MUST be classified as one of four types.

3.1 REUSE

Existing Book 3 responsibility is sufficient.

No architectural replacement is permitted.

3.2 REUSE + EXTEND

Existing Book 3 responsibility remains authoritative, but requires:

additional input
additional metadata
additional frequency
additional policy
additional adapter capability

3.3 MINIMAL CORE EXTENSION

An existing Book 3 Contract cannot represent a required Book 4 concept.

The extension MUST:

preserve existing fields
preserve existing semantics
preserve existing consumers
preserve backward compatibility

3.4 CONDITIONAL

The requirement may be necessary, but implementation is prohibited until its necessity is demonstrated.

Examples:

Tick
Streaming
Strategy Registry
Broker-specific latency optimization

---

4. Book 3 Core Reuse Boundary

The following Book 3 responsibilities remain unchanged.

Contract System
Config / Policy
Data Foundation
PIT
Feature Architecture
Universe
Market State
Event / State
Score / Confidence
Short-Term Signal
Ultra-Short-Term Signal
Action
Risk
Portfolio
Execution
Replay
Validation
Monitoring
Recovery
Audit
Kill Switch
Versioning

Book 4 does not reproduce these responsibilities.

---

5. Book 3 → Book 4 Architecture

The overall architecture becomes:

                         BOOK 3 CORE
────────────────────────────────────────────────────

Data / PIT
     ↓
Feature
     ↓
Universe
     ↓
Market State
     ↓
Event / State
     ↓
Score / Confidence
     ↓
Strategy / Signal
     ↓
Action
     ↓
Risk / Portfolio
     ↓
Execution
     ↓
Replay / Validation
     ↓
Monitoring / Recovery / Audit


────────────────── EXTENSION BOUNDARY ──────────────


                         BOOK 4

Intraday Data
Timestamp Resolution
Event-Time Context
Intraday Feature
Microstructure
Intraday Regime Resolution
Cost / Slippage
Execution Quality
Latency
Horizon Coordination
Conditional Streaming


────────────────────────────────────────────────────

The extension must connect to existing Book 3 boundaries rather than bypass them.

---

6. Horizon Architecture

6.1 Horizon is an Architectural Dimension

Book 4 recognizes:

LONG
MID
SHORT
ULTRA-SHORT

as different decision horizons.

However, Short and Ultra-Short are already present in Book 3.

Therefore Book 4 MUST NOT introduce new Short or Ultra-Short Engines merely because their data resolution becomes finer.

---

6.2 Horizon is Metadata / Policy First

The following conceptual attributes may be required:

horizon
holdingPeriod
decisionFrequency
dataFrequency
featurePolicy
signalPolicy
riskPolicy
executionPolicy

However, these are architecture concepts, not automatically fields of a common Contract.

Book 4 MUST NOT add all Horizon attributes to "BaseContract".

The actual Contract location is determined only when the relevant Contract is extended.

Possible locations include:

Strategy Policy
Signal
Decision
Risk Policy
Execution Policy

The exact field placement remains an implementation-level decision unless required by a frozen Contract.

---

7. BaseContract Rule

Book 3 BaseContract remains unchanged.

The common metadata responsibility is retained.

Book 4 MUST NOT add:

horizon
frequency
receivedAt
processedAt
executionTime

to BaseContract merely for convenience.

A field belongs in BaseContract only if it is semantically common to every Contract.

Horizon and operational latency metadata do not satisfy that condition by default.

---

8. Data Architecture

8.1 Existing Data Architecture

Book 3 Data Architecture remains authoritative.

Book 4 adds finer-grained market data.

Conceptually:

Existing Data
      ↓
Frequency Extension
      ↓
Intraday Data
      ↓
Existing Feature Architecture

Candidate frequencies:

Daily
Hourly
15m
5m
1m
Tick

The list is a supported design space, not a requirement that all frequencies be implemented.

---

8.2 Intraday Data Adapter

Book 4 may require a new adapter/provider layer for intraday data.

This adapter MUST feed the existing Data/Feature architecture.

It MUST NOT create a parallel data-processing architecture.

Market Data Source
        ↓
Intraday Adapter
        ↓
Existing Data Contract
        ↓
Existing Feature Store

Verdict:

NEW ADAPTER / MINIMAL EXTENSION

---

9. Timestamp and PIT Architecture

9.1 Existing PIT Rule

Book 3 PIT remains authoritative.

The fundamental rule is:

availableAt <= decisionTime

This rule MUST NOT be replaced by a new Book 4 PIT system.

---

9.2 Book 4 Timestamp Resolution

Book 4 may need to distinguish:

eventTime
exchangeTime
publicationTime
receivedAt
processedAt
decisionTime
executionTime

These represent different temporal semantics.

They MUST NOT automatically become mandatory fields in every Contract.

---

9.3 PIT vs Operational Time

Book 4 explicitly separates:

PIT Time
────────────────
eventTime
availableAt
decisionTime


Operational Time
────────────────
receivedAt
processedAt
executionTime
latency

The PIT model determines whether information was legally/causally available.

Operational timestamps measure system behavior.

These responsibilities MUST NOT be conflated.

---

10. Intraday PIT

Book 4 extends the resolution of PIT rather than creating a new PIT Engine.

Conceptually:

Book 3 PIT
     ↓
Higher timestamp resolution
     ↓
Intraday availableAt
     ↓
Existing PIT validation

For every derived feature:

availableAt(derived)
    >=
latest availableAt(input)

The existing Feature PIT propagation rule remains authoritative.

---

11. Feature Architecture

Book 3 Feature Architecture remains authoritative.

Existing responsibilities include:

Feature Calculator
Feature Store
Feature Provider
Feature Cache
Feature Versioning
PIT Propagation
Validation
Replay

Book 4 extends the Feature namespace.

Possible namespaces:

short/
intraday/
microstructure/
liquidity/
execution/

These are namespaces or feature families, not separate Engines.

---

11.1 Prohibited Architecture

Book 4 MUST NOT create:

ShortFeatureEngine
UltraShortFeatureEngine
IntradayFeatureEngine
MicrostructureEngine

unless a completely new responsibility is proven that cannot be represented by the existing Feature architecture.

Default implementation:

Existing Feature Architecture
        ↓
New Calculator / Feature Definition
        ↓
Existing Feature Store
        ↓
Existing PIT / Version / Validation

Verdict:

REUSE + EXTEND

---

12. Microstructure Architecture

Microstructure is the primary genuinely new information domain.

Candidate information:

Bid
Ask
Spread
Depth
Trade
Order Flow
Volume Imbalance
Trade Intensity
Liquidity
Queue-related information

Microstructure is NOT a new Strategy Engine.

It enters through:

Data
 ↓
Feature
 ↓
Market State / Signal
 ↓
Risk
 ↓
Execution

---

12.1 Microstructure Adoption Gate

No microstructure feature becomes Production merely because the data exists.

Minimum conditions:

Available
+
PIT Safe
+
Reliable
+
Incremental Edge
+
Cost-adjusted
+
Testable

If the feature fails the adoption gate, it remains Research-only.

---

13. Market State / Regime

Book 3 already contains:

Trend State
Momentum State
Volume State
Market Regime

Therefore Market Regime is NOT a Book 4 New Engine.

Book 4 extends its temporal resolution.

Book 3 Market State
        ↓
Intraday Resolution
        ↓
Existing Signal Layer

Verdict:

REUSE + EXTEND

---

14. Event Architecture

Book 3 Event / State architecture remains authoritative.

Book 4 extends temporal precision and event ordering.

Potential operational metadata:

Event ID
Event Time
Sequence
Version
Received At
Processed At

These fields are not automatically frozen into the existing Event Contract.

They are added only if required by the selected execution model.

---

14.1 Event Ordering

If multiple events occur within a decision interval, the system must preserve deterministic ordering.

Required concepts:

Event Identity
Event Time
Ordering
Duplicate Detection
Late Event Classification

A late event MUST NOT silently rewrite a historical decision.

---

15. State Architecture

Book 3 State Architecture remains authoritative.

Book 4 extends state only when intraday or streaming operation creates a new state-management requirement.

Existing state concepts remain:

Market State
Position State
Order State
Risk State
System State

Book 4 may add finer-grained state transitions.

It MUST NOT create a second State Manager.

Verdict:

REUSE + EXTEND

Streaming-specific state is:

CONDITIONAL

until streaming itself is approved.

---

16. Score Architecture

Book 3 Score Engine remains authoritative.

Book 4 MUST NOT create:

ShortScoreEngine
UltraShortScoreEngine
IntradayScoreEngine

The existing Score Engine is reused with additional:

features
criteria
policies
frequency-specific inputs

where necessary.

---

16.1 Horizon in Score

"horizon" is NOT automatically added to Score Contract.

Before changing Score Contract, determine whether horizon is already fully represented by:

Criteria
Policy
Strategy
Configuration

If yes:

Score Contract = REUSE

If not:

Minimal Contract Extension

is considered.

No Contract change is approved merely for architectural symmetry.

---

17. Signal Architecture

Book 3 already provides:

Short-Term Signal
Ultra-Short-Term Signal

Therefore Book 4 does not create new Signal Engines.

Book 4 provides additional information:

Intraday Feature
Microstructure
Event-Time Context
Liquidity
Cost
Execution Context

to the existing Signal architecture.

Conceptually:

Existing Signal
       ↑
 ┌─────┼─────────────┐
 │     │             │
Feature State   Microstructure
 │     │             │
 └─────┴─────────────┘

Verdict:

REUSE + EXTEND

---

18. Action / Portfolio Architecture

Book 3 already separates:

Signal
Action
Risk
Portfolio
Execution

and already addresses Multi-Horizon Agreement.

Therefore Book 4 MUST NOT create:

MultiHorizonPortfolioEngine

The new responsibility is coordination policy.

Long Signal
Short Signal
Ultra-Short Signal
        ↓
Existing Action / Portfolio Boundary
        ↓
Horizon Coordination Policy
        ↓
Existing Risk
        ↓
Existing Execution

A disagreement between horizons is not automatically an error.

---

19. Horizon Coordination Policy

The coordination policy may consider:

Horizon
Signal
Confidence
Position
Exposure
Risk Budget
Liquidity
Correlation
Cost
Execution State

The policy determines whether signals:

reinforce
coexist
reduce
override
or remain independent

The policy MUST NOT merge all horizons into one Score.

Long BUY + Short SELL can be a valid system state.

---

20. Risk Architecture

Book 3 Risk Engine remains authoritative.

Book 4 extends Risk Policy.

Candidate intraday controls:

Daily Loss Limit
Frequency Risk
Overtrading Control
Spread Risk
Slippage Risk
Volatility Spike
Liquidity Risk
Execution Risk
Circuit Breaker

These are policy extensions unless a new responsibility is demonstrated.

Architecture:

Existing Risk Engine
        ↓
Intraday Risk Policy
        ↓
Existing Risk Gate
        ↓
Existing Action / Execution Boundary

Verdict:

REUSE + EXTEND

---

21. Cost Architecture

Book 3 already contains Transaction Cost and Slippage concepts.

Book 4 makes them more important for short-horizon viability.

Conceptually:

Expected Edge
    -
Fees
    -
Taxes
    -
Spread
    -
Slippage
    -
Impact
    -
Latency Cost
    =
Expected Net Edge

Not every cost component must exist as an independent Engine.

The default is:

Existing Cost / Slippage Capability
        ↓
Additional Policy / Measurement

---

22. Execution Architecture

Book 3 Execution remains authoritative.

Existing boundaries include:

Action
Risk Gate
Portfolio Constraint
Order Intent
Execution Adapter
Execution Status
Idempotency
Reconciliation
Audit

Book 4 MUST NOT create a second Execution Engine.

---

22.1 Execution Quality

Book 4 adds measurement of:

Fill Rate
Slippage
Market Impact
Price Improvement
Execution Latency

These are initially treated as Execution Quality measurements, not necessarily as mandatory Execution Contract fields.

Architecture:

Existing Execution
       ↓
Execution Result
       ↓
Execution Quality Measurement
       ├── Cost
       ├── Slippage
       ├── Fill
       ├── Impact
       └── Latency

Verdict:

REUSE + EXTEND

---

23. Latency Architecture

Latency is measured only when it is decision-relevant.

Candidate measurements:

Feed Latency
Processing Latency
Decision Latency
Network Latency
Broker Latency

Do not optimize latency before establishing:

latency affects signal
OR
latency affects execution
OR
latency affects expected edge

If latency is not material, Batch/Replay remains the preferred architecture.

---

24. Streaming Architecture

Streaming is NOT a Book 4 Core requirement at Freeze Candidate stage.

The default architecture remains:

Batch / Replay

Streaming becomes an optional extension.

If approved:

Market Feed
    ↓
Streaming Adapter
    ↓
Existing Event
    ↓
Existing State
    ↓
Existing Feature
    ↓
Existing Signal
    ↓
Existing Risk
    ↓
Existing Action
    ↓
Existing Execution

Streaming MUST NOT bypass existing Contracts.

---

24.1 Streaming Approval Gate

Streaming can be approved only if:

Batch / Replay cannot provide required edge
OR
required decision latency cannot be achieved

Until then:

Streaming = CONDITIONAL

---

25. Tick Data Policy

Tick is not automatically required.

Tick data must pass:

Need
↓
Information Content
↓
Feature
↓
Signal
↓
Incremental Edge
↓
Cost
↓
Storage / Processing Feasibility

If 1-minute or 5-minute data provides equivalent information, Tick should not be adopted merely because it provides higher resolution.

Verdict:

CONDITIONAL

---

26. Strategy Registry

Strategy Registry is not yet a confirmed Book 4 module.

First determine whether existing Book 3:

Strategy
Config
Policy
Version

already provides sufficient identity and lifecycle management.

Only a demonstrated operational gap may justify a separate Registry.

Verdict:

CONDITIONAL

---

27. Replay / Validation

Book 3 Replay and Validation remain authoritative.

Book 4 extends the same validation architecture to intraday data.

Required validation includes:

PIT
Lookahead Bias
Survivorship Bias
Data Snooping
Overfitting
Transaction Cost
Slippage
Execution Feasibility
Latency
Deterministic Replay

The validation system must compare:

Gross Edge
vs
Net Edge

and:

Theoretical Execution
vs
Feasible Execution

---

28. Monitoring / Recovery / Audit

Book 3 Monitoring, Recovery and Audit remain authoritative.

Book 4 extends measurements to:

Feed Health
Data Freshness
Latency
Spread
Liquidity
Signal Frequency
Order Frequency
Slippage
Fill Rate
Execution Quality

Existing recovery and Kill Switch behavior remains unchanged unless a specific intraday failure mode requires an extension.

---

29. Dependency Rule

Book 3's isolation rule remains unchanged.

The preferred dependency direction is:

Contract
   ↓
Feature / State / Event
   ↓
Engine
   ↓
Policy

Book 4 MUST NOT introduce direct Engine-to-Engine shortcuts.

Example prohibited structure:

Microstructure Engine
        ↓
Risk Engine

Preferred structure:

Microstructure Feature
        ↓
Existing Signal / Risk Contract
        ↓
Existing Engine

---

30. Backward Compatibility

Every Book 4 extension MUST satisfy:

Existing Book 3 input
        ↓
Existing Book 3 behavior

unless the change is explicitly versioned and approved.

Rules:

Existing fields remain valid.
Existing consumers remain valid.
Existing replay remains reproducible.
Existing contracts remain versioned.
Existing production safety controls remain active.

No silent semantic change is permitted.

---

31. Book 3 / Book 4 Final Boundary

                         BOOK 3
────────────────────────────────────────────────────

Contract System
Data / PIT
Feature
Universe
Market State
Event / State
Score / Confidence
Short Signal
Ultra-Short Signal
Action
Risk
Portfolio
Execution
Replay
Validation
Monitoring
Recovery
Audit
Kill Switch
Versioning

──────────────────── EXTENSION POINT ───────────────

                         BOOK 4

Intraday Data
Timestamp Resolution
Event-Time Context
Intraday Feature
Microstructure
Intraday Regime Resolution
Cost / Slippage Extension
Execution Quality
Latency
Horizon Coordination Policy

                 CONDITIONAL

Streaming Adapter
Tick Data
Strategy Registry
Broker-specific Optimization

────────────────────────────────────────────────────

---

32. Final Classification Matrix

Area| Book 4 Decision
BaseContract| REUSE
Config System| REUSE + EXTEND
Data Foundation| REUSE + MINIMAL EXTENSION
Intraday Data| EXTENSION / NEW ADAPTER
PIT| REUSE
Timestamp Semantics| REUSE + EXTEND
Feature Architecture| REUSE + EXTEND
Microstructure| NEW INFORMATION DOMAIN
Market State| REUSE + EXTEND
Event| REUSE + EXTEND
State| REUSE + EXTEND
Score| REUSE
Confidence| REUSE + EXTEND if required
Short Signal| REUSE + EXTEND
Ultra-Short Signal| REUSE + EXTEND
Action| REUSE + EXTEND
Portfolio| REUSE + COORDINATION POLICY
Risk| REUSE + POLICY EXTENSION
Cost / Slippage| REUSE + EXTEND
Execution| REUSE + EXTEND
Execution Quality| NEW MEASUREMENT DOMAIN
Replay| REUSE + EXTEND
Validation| REUSE + EXTEND
Monitoring| REUSE + EXTEND
Recovery| REUSE + EXTEND
Audit| REUSE + EXTEND
Latency| NEW MEASUREMENT DOMAIN
Streaming| CONDITIONAL
Tick| CONDITIONAL
Strategy Registry| CONDITIONAL

---

33. Implementation Priority

P0 — Foundation

Intraday Data Extension
Timestamp Resolution
PIT Compatibility
Frequency Policy
Horizon Metadata Location

No Core Engine replacement.

---

P1 — Information

Intraday Feature
Microstructure
Intraday Market State
Event-Time Context
Liquidity
Volatility

---

P2 — Decision Economics

Cost
Spread
Slippage
Expected Net Edge
Horizon Coordination

---

P3 — Execution Quality

Fill Rate
Market Impact
Price Improvement
Latency Measurement
Execution Feasibility

---

P4 — Conditional Runtime

Streaming Adapter
Event Ordering
Duplicate Event
Late Event
Feed Recovery

Only after the Streaming Approval Gate is satisfied.

---

P5 — Evidence

Intraday Replay
Walk-Forward
OOS
Cost-adjusted Validation
Paper
Shadow
Production

---

34. Architecture Freeze Rules

Architecture Freeze requires:

1. Book 3 Core boundary confirmed
2. No duplicate Engine introduced
3. Intraday Data boundary defined
4. Timestamp/PIT semantics defined
5. Horizon metadata location defined
6. Feature extension boundary defined
7. Microstructure adoption boundary defined
8. Horizon coordination boundary defined
9. Risk extension boundary defined
10. Execution Quality boundary defined
11. Conditional Streaming gate defined
12. Backward Compatibility defined

Freeze does NOT require:

Tick implementation
Streaming implementation
Broker optimization
All Intraday features
All Short/Ultra-Short strategies

Those are implementation/validation decisions after Freeze.

---

35. Freeze Candidate Decision

Current architecture status:

BOOK4_ARCHITECTURE_v3
        ↓
ARCHITECTURE FREEZE CANDIDATE

The following are now architecturally fixed:

Book 3 Core is authoritative.
Book 4 is an Extension Layer.
Short/Ultra-Short are reused.
Score/Risk/Execution are reused.
PIT is reused.
Feature architecture is reused.
Market State is reused.
Event/State are reused.
Replay/Validation are reused.
No duplicate Engine is permitted.

The following remain implementation-level decisions:

Exact Intraday Contract fields
Exact Timestamp field placement
Exact Horizon metadata location
Exact Microstructure Feature schema
Exact Execution Quality schema
Exact Latency schema

These MUST be resolved from the actual implementation requirements before coding, but they do not justify redesigning the architecture.

---

36. Coding-Agent Rule

Claude Code / Codex MUST follow this order:

BOOK4_MASTER.md
        ↓
BOOK4_ARCHITECTURE_v3.md
        ↓
Relevant Book 4 Chapter
        ↓
Book 3 existing specification / implementation
        ↓
Current Repository
        ↓
Search existing implementation first
        ↓
Minimal Extension
        ↓
Backward Compatibility Test
        ↓
Book 4 Test

The coding agent MUST NOT:

create a duplicate Engine
create a duplicate Contract without justification
replace Book 3 PIT
replace Book 3 Risk
replace Book 3 Execution
replace Book 3 Signal
replace Book 3 Replay
introduce Streaming before approval
introduce Tick before evidence

---

37. Architecture Principle

The fundamental Book 4 principle is:

BOOK 3
provides the system.

BOOK 4
increases the resolution of information,
time,
decision,
and execution.

Therefore:

Book 4 ≠ New Trading System

Book 4 = Book 3
       + Intraday Information
       + Event-Time Resolution
       + Microstructure
       + Cost / Execution Quality
       + Latency
       + Horizon Coordination

This is the architectural boundary for all subsequent Book 4 design and implementation.